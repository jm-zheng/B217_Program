﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請勿使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.ec = New System.Windows.Forms.Label()
        Me.el = New System.Windows.Forms.Label()
        Me.ev = New System.Windows.Forms.Label()
        Me.ef = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.et = New System.Windows.Forms.Label()
        Me.eh = New System.Windows.Forms.Label()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.turn3 = New System.Windows.Forms.Label()
        Me.te = New System.Windows.Forms.Label()
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.GroupBox15 = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.turn = New System.Windows.Forms.Label()
        Me.up3 = New System.Windows.Forms.Label()
        Me.motor3 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.down3 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.SS3 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.SA3 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.SC3 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.ST3 = New System.Windows.Forms.Label()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.nama3 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.number3 = New System.Windows.Forms.Label()
        Me.status3 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.manager3 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.nama2 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.number2 = New System.Windows.Forms.Label()
        Me.manager2 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.status2 = New System.Windows.Forms.Label()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.turn2 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.motor2 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.up2 = New System.Windows.Forms.Label()
        Me.down2 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.SC2 = New System.Windows.Forms.Label()
        Me.ST2 = New System.Windows.Forms.Label()
        Me.SA2 = New System.Windows.Forms.Label()
        Me.SS2 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.SS1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SA1 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SC1 = New System.Windows.Forms.Label()
        Me.ST1 = New System.Windows.Forms.Label()
        Me.PD1 = New System.Windows.Forms.Label()
        Me.noc1 = New System.Windows.Forms.Label()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.name1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.status1 = New System.Windows.Forms.Label()
        Me.number1 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Manager1 = New System.Windows.Forms.Label()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.turn1 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.motor1 = New System.Windows.Forms.Label()
        Me.up1 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.down1 = New System.Windows.Forms.Label()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.PD2333 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer5 = New System.Windows.Forms.Timer(Me.components)
        Me.Label54 = New System.Windows.Forms.Label()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox15.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox14.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label15
        '
        Me.Label15.AutoEllipsis = True
        Me.Label15.BackColor = System.Drawing.Color.Silver
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label15.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label15.Location = New System.Drawing.Point(13, 32)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(68, 24)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "COM埠"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label16.Location = New System.Drawing.Point(13, 69)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(247, 115)
        Me.Label16.TabIndex = 2
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(87, 32)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(106, 28)
        Me.ComboBox1.TabIndex = 3
        Me.ComboBox1.Text = "選擇Port"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Button1.Location = New System.Drawing.Point(201, 32)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(56, 28)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "搜尋"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Controls.Add(Me.GroupBox4)
        Me.GroupBox2.Controls.Add(Me.Button12)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.ComboBox1)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Location = New System.Drawing.Point(2, 1)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(273, 609)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "智慧工業機上盒"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Button2)
        Me.GroupBox4.Controls.Add(Me.Button5)
        Me.GroupBox4.Controls.Add(Me.DataGridView1)
        Me.GroupBox4.Controls.Add(Me.Label66)
        Me.GroupBox4.Controls.Add(Me.Label22)
        Me.GroupBox4.Controls.Add(Me.Label30)
        Me.GroupBox4.Controls.Add(Me.Label25)
        Me.GroupBox4.Controls.Add(Me.Label26)
        Me.GroupBox4.Controls.Add(Me.ec)
        Me.GroupBox4.Controls.Add(Me.el)
        Me.GroupBox4.Controls.Add(Me.ev)
        Me.GroupBox4.Controls.Add(Me.ef)
        Me.GroupBox4.Controls.Add(Me.Label21)
        Me.GroupBox4.Controls.Add(Me.Label50)
        Me.GroupBox4.Controls.Add(Me.Label48)
        Me.GroupBox4.Controls.Add(Me.Label47)
        Me.GroupBox4.Controls.Add(Me.Label45)
        Me.GroupBox4.Controls.Add(Me.Label23)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Controls.Add(Me.et)
        Me.GroupBox4.Controls.Add(Me.eh)
        Me.GroupBox4.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(6, 282)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(261, 293)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "環境感測"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(146, 245)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(105, 40)
        Me.Button2.TabIndex = 19
        Me.Button2.Text = "輪播"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(10, 245)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(130, 42)
        Me.Button5.TabIndex = 7
        Me.Button5.Text = "上傳資料"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6})
        Me.DataGridView1.Location = New System.Drawing.Point(-188, 293)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(636, 168)
        Me.DataGridView1.TabIndex = 9
        '
        'Column1
        '
        Me.Column1.HeaderText = "溫度"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "濕度"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.HeaderText = "CO2"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.HeaderText = "甲醛"
        Me.Column4.Name = "Column4"
        '
        'Column5
        '
        Me.Column5.HeaderText = "TVOC"
        Me.Column5.Name = "Column5"
        '
        'Column6
        '
        Me.Column6.HeaderText = "光照度"
        Me.Column6.Name = "Column6"
        '
        'Label66
        '
        Me.Label66.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label66.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label66.Location = New System.Drawing.Point(10, 206)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(102, 30)
        Me.Label66.TabIndex = 10
        Me.Label66.Text = "光照度"
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label22.Location = New System.Drawing.Point(10, 29)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(102, 30)
        Me.Label22.TabIndex = 7
        Me.Label22.Text = "溫度"
        '
        'Label30
        '
        Me.Label30.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label30.Location = New System.Drawing.Point(10, 170)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(102, 30)
        Me.Label30.TabIndex = 10
        Me.Label30.Text = "TVOC"
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label25.Location = New System.Drawing.Point(10, 137)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(102, 30)
        Me.Label25.TabIndex = 10
        Me.Label25.Text = "甲醛"
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label26.Location = New System.Drawing.Point(10, 101)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(102, 30)
        Me.Label26.TabIndex = 11
        Me.Label26.Text = "CO2"
        '
        'ec
        '
        Me.ec.BackColor = System.Drawing.Color.LightGreen
        Me.ec.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ec.Location = New System.Drawing.Point(123, 101)
        Me.ec.Name = "ec"
        Me.ec.Size = New System.Drawing.Size(84, 30)
        Me.ec.TabIndex = 8
        '
        'el
        '
        Me.el.BackColor = System.Drawing.Color.LightGreen
        Me.el.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.el.Location = New System.Drawing.Point(123, 207)
        Me.el.Name = "el"
        Me.el.Size = New System.Drawing.Size(84, 30)
        Me.el.TabIndex = 9
        '
        'ev
        '
        Me.ev.BackColor = System.Drawing.Color.LightGreen
        Me.ev.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ev.Location = New System.Drawing.Point(123, 170)
        Me.ev.Name = "ev"
        Me.ev.Size = New System.Drawing.Size(84, 30)
        Me.ev.TabIndex = 9
        '
        'ef
        '
        Me.ef.BackColor = System.Drawing.Color.LightGreen
        Me.ef.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ef.Location = New System.Drawing.Point(123, 137)
        Me.ef.Name = "ef"
        Me.ef.Size = New System.Drawing.Size(84, 30)
        Me.ef.TabIndex = 9
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label21.Location = New System.Drawing.Point(10, 64)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(102, 30)
        Me.Label21.TabIndex = 6
        Me.Label21.Text = "濕度"
        '
        'Label50
        '
        Me.Label50.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label50.CausesValidation = False
        Me.Label50.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label50.Location = New System.Drawing.Point(213, 206)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(38, 30)
        Me.Label50.TabIndex = 4
        Me.Label50.Text = "lux"
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label48
        '
        Me.Label48.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label48.CausesValidation = False
        Me.Label48.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label48.Location = New System.Drawing.Point(213, 169)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(38, 30)
        Me.Label48.TabIndex = 4
        Me.Label48.Text = "ppm"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label47
        '
        Me.Label47.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label47.CausesValidation = False
        Me.Label47.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label47.Location = New System.Drawing.Point(213, 136)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(38, 30)
        Me.Label47.TabIndex = 4
        Me.Label47.Text = "ppm"
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label45
        '
        Me.Label45.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label45.CausesValidation = False
        Me.Label45.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label45.Location = New System.Drawing.Point(213, 100)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(38, 30)
        Me.Label45.TabIndex = 4
        Me.Label45.Text = "ppm"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label23.CausesValidation = False
        Me.Label23.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label23.Location = New System.Drawing.Point(213, 63)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(38, 30)
        Me.Label23.TabIndex = 4
        Me.Label23.Text = "度"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label10.CausesValidation = False
        Me.Label10.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label10.Location = New System.Drawing.Point(213, 28)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(38, 30)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "度"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'et
        '
        Me.et.BackColor = System.Drawing.Color.LightGreen
        Me.et.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.et.Location = New System.Drawing.Point(123, 29)
        Me.et.Name = "et"
        Me.et.Size = New System.Drawing.Size(84, 30)
        Me.et.TabIndex = 4
        '
        'eh
        '
        Me.eh.BackColor = System.Drawing.Color.LightGreen
        Me.eh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.eh.Location = New System.Drawing.Point(123, 64)
        Me.eh.Name = "eh"
        Me.eh.Size = New System.Drawing.Size(84, 30)
        Me.eh.TabIndex = 5
        '
        'Button12
        '
        Me.Button12.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Button12.Location = New System.Drawing.Point(178, 613)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(79, 48)
        Me.Button12.TabIndex = 4
        Me.Button12.Text = "查詢"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label20.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label20.Location = New System.Drawing.Point(94, 249)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(166, 28)
        Me.Label20.TabIndex = 1
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label18.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label18.Location = New System.Drawing.Point(94, 208)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(166, 30)
        Me.Label18.TabIndex = 1
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label17.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label17.Location = New System.Drawing.Point(16, 247)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(72, 30)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "時間"
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label19.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label19.Location = New System.Drawing.Point(16, 208)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(72, 30)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "日期"
        '
        'Timer1
        '
        '
        'turn3
        '
        Me.turn3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.turn3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.turn3.Location = New System.Drawing.Point(113, 23)
        Me.turn3.Name = "turn3"
        Me.turn3.Size = New System.Drawing.Size(77, 23)
        Me.turn3.TabIndex = 3
        '
        'te
        '
        Me.te.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.te.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.te.Location = New System.Drawing.Point(113, 23)
        Me.te.Name = "te"
        Me.te.Size = New System.Drawing.Size(77, 23)
        Me.te.TabIndex = 3
        '
        'Timer3
        '
        '
        'GroupBox6
        '
        Me.GroupBox6.BackColor = System.Drawing.Color.Yellow
        Me.GroupBox6.Controls.Add(Me.Label31)
        Me.GroupBox6.Controls.Add(Me.GroupBox15)
        Me.GroupBox6.Controls.Add(Me.PictureBox3)
        Me.GroupBox6.Controls.Add(Me.GroupBox14)
        Me.GroupBox6.Controls.Add(Me.Button8)
        Me.GroupBox6.Controls.Add(Me.TextBox3)
        Me.GroupBox6.Controls.Add(Me.GroupBox13)
        Me.GroupBox6.Controls.Add(Me.Label38)
        Me.GroupBox6.Location = New System.Drawing.Point(643, 88)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox6.Size = New System.Drawing.Size(296, 476)
        Me.GroupBox6.TabIndex = 0
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "機台3"
        '
        'Label31
        '
        Me.Label31.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label31.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label31.Location = New System.Drawing.Point(9, 232)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(135, 36)
        Me.Label31.TabIndex = 12
        '
        'GroupBox15
        '
        Me.GroupBox15.Controls.Add(Me.Label8)
        Me.GroupBox15.Controls.Add(Me.Label40)
        Me.GroupBox15.Controls.Add(Me.Label13)
        Me.GroupBox15.Controls.Add(Me.turn)
        Me.GroupBox15.Controls.Add(Me.up3)
        Me.GroupBox15.Controls.Add(Me.motor3)
        Me.GroupBox15.Controls.Add(Me.Label78)
        Me.GroupBox15.Controls.Add(Me.down3)
        Me.GroupBox15.Location = New System.Drawing.Point(368, 226)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Size = New System.Drawing.Size(201, 150)
        Me.GroupBox15.TabIndex = 10
        Me.GroupBox15.TabStop = False
        Me.GroupBox15.Text = "機台狀況"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label8.Location = New System.Drawing.Point(9, 53)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(98, 23)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "品檢上升"
        '
        'Label40
        '
        Me.Label40.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label40.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label40.Location = New System.Drawing.Point(9, 84)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(98, 23)
        Me.Label40.TabIndex = 6
        Me.Label40.Text = "品檢下降"
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label13.Location = New System.Drawing.Point(9, 23)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(98, 23)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "直進旋轉"
        '
        'turn
        '
        Me.turn.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.turn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.turn.Location = New System.Drawing.Point(113, 23)
        Me.turn.Name = "turn"
        Me.turn.Size = New System.Drawing.Size(77, 23)
        Me.turn.TabIndex = 5
        '
        'up3
        '
        Me.up3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.up3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.up3.Location = New System.Drawing.Point(113, 53)
        Me.up3.Name = "up3"
        Me.up3.Size = New System.Drawing.Size(77, 23)
        Me.up3.TabIndex = 5
        '
        'motor3
        '
        Me.motor3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.motor3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.motor3.Location = New System.Drawing.Point(113, 115)
        Me.motor3.Name = "motor3"
        Me.motor3.Size = New System.Drawing.Size(77, 23)
        Me.motor3.TabIndex = 1
        '
        'Label78
        '
        Me.Label78.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label78.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label78.Location = New System.Drawing.Point(9, 117)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(98, 23)
        Me.Label78.TabIndex = 1
        Me.Label78.Text = "輸送帶馬達"
        '
        'down3
        '
        Me.down3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.down3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.down3.Location = New System.Drawing.Point(113, 84)
        Me.down3.Name = "down3"
        Me.down3.Size = New System.Drawing.Size(77, 23)
        Me.down3.TabIndex = 5
        '
        'PictureBox3
        '
        Me.PictureBox3.ErrorImage = Global.WindowsApp2.My.Resources.Resources.list_11939741650
        Me.PictureBox3.Image = Global.WindowsApp2.My.Resources.Resources.list_11939741650
        Me.PictureBox3.Location = New System.Drawing.Point(6, 79)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(277, 150)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 11
        Me.PictureBox3.TabStop = False
        '
        'GroupBox14
        '
        Me.GroupBox14.Controls.Add(Me.SS3)
        Me.GroupBox14.Controls.Add(Me.Label53)
        Me.GroupBox14.Controls.Add(Me.Label51)
        Me.GroupBox14.Controls.Add(Me.SA3)
        Me.GroupBox14.Controls.Add(Me.Label49)
        Me.GroupBox14.Controls.Add(Me.SC3)
        Me.GroupBox14.Controls.Add(Me.Label72)
        Me.GroupBox14.Controls.Add(Me.ST3)
        Me.GroupBox14.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.GroupBox14.Location = New System.Drawing.Point(377, 33)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Size = New System.Drawing.Size(270, 193)
        Me.GroupBox14.TabIndex = 9
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "感測狀態"
        '
        'SS3
        '
        Me.SS3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SS3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SS3.Location = New System.Drawing.Point(137, 30)
        Me.SS3.Name = "SS3"
        Me.SS3.Size = New System.Drawing.Size(126, 35)
        Me.SS3.TabIndex = 1
        '
        'Label53
        '
        Me.Label53.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label53.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label53.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label53.Location = New System.Drawing.Point(6, 30)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(126, 35)
        Me.Label53.TabIndex = 1
        Me.Label53.Text = "震動指數"
        '
        'Label51
        '
        Me.Label51.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label51.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label51.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label51.Location = New System.Drawing.Point(6, 68)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(126, 35)
        Me.Label51.TabIndex = 1
        Me.Label51.Text = "物件數量"
        '
        'SA3
        '
        Me.SA3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SA3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SA3.Location = New System.Drawing.Point(137, 148)
        Me.SA3.Name = "SA3"
        Me.SA3.Size = New System.Drawing.Size(126, 35)
        Me.SA3.TabIndex = 1
        '
        'Label49
        '
        Me.Label49.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label49.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label49.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label49.Location = New System.Drawing.Point(6, 108)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(126, 35)
        Me.Label49.TabIndex = 1
        Me.Label49.Text = "機台溫度"
        '
        'SC3
        '
        Me.SC3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SC3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SC3.Location = New System.Drawing.Point(137, 68)
        Me.SC3.Name = "SC3"
        Me.SC3.Size = New System.Drawing.Size(126, 35)
        Me.SC3.TabIndex = 1
        '
        'Label72
        '
        Me.Label72.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label72.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label72.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label72.Location = New System.Drawing.Point(6, 148)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(126, 35)
        Me.Label72.TabIndex = 1
        Me.Label72.Text = "機台電流"
        '
        'ST3
        '
        Me.ST3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ST3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ST3.Location = New System.Drawing.Point(137, 108)
        Me.ST3.Name = "ST3"
        Me.ST3.Size = New System.Drawing.Size(126, 35)
        Me.ST3.TabIndex = 1
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Button8.Location = New System.Drawing.Point(150, 232)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(133, 42)
        Me.Button8.TabIndex = 8
        Me.Button8.Text = "紀錄資料"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(152, 37)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 33)
        Me.TextBox3.TabIndex = 6
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.nama3)
        Me.GroupBox13.Controls.Add(Me.Label58)
        Me.GroupBox13.Controls.Add(Me.Label57)
        Me.GroupBox13.Controls.Add(Me.number3)
        Me.GroupBox13.Controls.Add(Me.status3)
        Me.GroupBox13.Controls.Add(Me.Label55)
        Me.GroupBox13.Controls.Add(Me.manager3)
        Me.GroupBox13.Controls.Add(Me.Label46)
        Me.GroupBox13.Location = New System.Drawing.Point(9, 273)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(274, 196)
        Me.GroupBox13.TabIndex = 7
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "機台履歷"
        '
        'nama3
        '
        Me.nama3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.nama3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.nama3.Location = New System.Drawing.Point(141, 30)
        Me.nama3.Name = "nama3"
        Me.nama3.Size = New System.Drawing.Size(126, 35)
        Me.nama3.TabIndex = 1
        '
        'Label58
        '
        Me.Label58.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label58.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label58.Location = New System.Drawing.Point(6, 32)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(126, 35)
        Me.Label58.TabIndex = 1
        Me.Label58.Text = "區域顯示"
        '
        'Label57
        '
        Me.Label57.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label57.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label57.Location = New System.Drawing.Point(6, 71)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(126, 35)
        Me.Label57.TabIndex = 1
        Me.Label57.Text = "機台名稱"
        '
        'number3
        '
        Me.number3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.number3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.number3.Location = New System.Drawing.Point(141, 71)
        Me.number3.Name = "number3"
        Me.number3.Size = New System.Drawing.Size(126, 35)
        Me.number3.TabIndex = 1
        '
        'status3
        '
        Me.status3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.status3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.status3.Location = New System.Drawing.Point(143, 151)
        Me.status3.Name = "status3"
        Me.status3.Size = New System.Drawing.Size(126, 35)
        Me.status3.TabIndex = 1
        Me.status3.Text = "待機狀態"
        '
        'Label55
        '
        Me.Label55.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label55.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label55.Location = New System.Drawing.Point(6, 111)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(126, 35)
        Me.Label55.TabIndex = 1
        Me.Label55.Text = "管理者"
        '
        'manager3
        '
        Me.manager3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.manager3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.manager3.Location = New System.Drawing.Point(143, 110)
        Me.manager3.Name = "manager3"
        Me.manager3.Size = New System.Drawing.Size(126, 35)
        Me.manager3.TabIndex = 1
        '
        'Label46
        '
        Me.Label46.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label46.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label46.Location = New System.Drawing.Point(8, 151)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(126, 35)
        Me.Label46.TabIndex = 1
        Me.Label46.Text = "狀態顯示"
        '
        'Label38
        '
        Me.Label38.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label38.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label38.Font = New System.Drawing.Font("新細明體", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label38.Location = New System.Drawing.Point(36, 37)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(109, 33)
        Me.Label38.TabIndex = 3
        Me.Label38.Text = "工單件數"
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.Yellow
        Me.GroupBox5.Controls.Add(Me.PictureBox2)
        Me.GroupBox5.Controls.Add(Me.GroupBox8)
        Me.GroupBox5.Controls.Add(Me.GroupBox9)
        Me.GroupBox5.Controls.Add(Me.GroupBox3)
        Me.GroupBox5.Controls.Add(Me.TextBox2)
        Me.GroupBox5.Controls.Add(Me.Button7)
        Me.GroupBox5.Controls.Add(Me.Label28)
        Me.GroupBox5.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(335, 88)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Size = New System.Drawing.Size(297, 476)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "機台2"
        '
        'PictureBox2
        '
        Me.PictureBox2.ErrorImage = Global.WindowsApp2.My.Resources.Resources.dmg_mori
        Me.PictureBox2.Image = Global.WindowsApp2.My.Resources.Resources.dmg_mori
        Me.PictureBox2.Location = New System.Drawing.Point(7, 78)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(276, 150)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 10
        Me.PictureBox2.TabStop = False
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.nama2)
        Me.GroupBox8.Controls.Add(Me.Label44)
        Me.GroupBox8.Controls.Add(Me.Label43)
        Me.GroupBox8.Controls.Add(Me.Label41)
        Me.GroupBox8.Controls.Add(Me.number2)
        Me.GroupBox8.Controls.Add(Me.manager2)
        Me.GroupBox8.Controls.Add(Me.Label32)
        Me.GroupBox8.Controls.Add(Me.status2)
        Me.GroupBox8.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.GroupBox8.Location = New System.Drawing.Point(5, 273)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(278, 196)
        Me.GroupBox8.TabIndex = 8
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "機台履歷"
        '
        'nama2
        '
        Me.nama2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.nama2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.nama2.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.nama2.Location = New System.Drawing.Point(145, 30)
        Me.nama2.Name = "nama2"
        Me.nama2.Size = New System.Drawing.Size(126, 35)
        Me.nama2.TabIndex = 1
        '
        'Label44
        '
        Me.Label44.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label44.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label44.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label44.Location = New System.Drawing.Point(9, 30)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(126, 35)
        Me.Label44.TabIndex = 1
        Me.Label44.Text = "區域顯示"
        '
        'Label43
        '
        Me.Label43.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label43.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label43.Location = New System.Drawing.Point(9, 71)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(126, 35)
        Me.Label43.TabIndex = 1
        Me.Label43.Text = "工件名稱"
        '
        'Label41
        '
        Me.Label41.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label41.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label41.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label41.Location = New System.Drawing.Point(9, 111)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(126, 35)
        Me.Label41.TabIndex = 1
        Me.Label41.Text = "管理者"
        '
        'number2
        '
        Me.number2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.number2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.number2.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.number2.Location = New System.Drawing.Point(145, 71)
        Me.number2.Name = "number2"
        Me.number2.Size = New System.Drawing.Size(126, 35)
        Me.number2.TabIndex = 1
        '
        'manager2
        '
        Me.manager2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.manager2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.manager2.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.manager2.Location = New System.Drawing.Point(145, 111)
        Me.manager2.Name = "manager2"
        Me.manager2.Size = New System.Drawing.Size(126, 35)
        Me.manager2.TabIndex = 1
        '
        'Label32
        '
        Me.Label32.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label32.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label32.Location = New System.Drawing.Point(9, 151)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(126, 35)
        Me.Label32.TabIndex = 1
        Me.Label32.Text = "狀態顯示"
        '
        'status2
        '
        Me.status2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.status2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.status2.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.status2.Location = New System.Drawing.Point(145, 151)
        Me.status2.Name = "status2"
        Me.status2.Size = New System.Drawing.Size(126, 35)
        Me.status2.TabIndex = 1
        Me.status2.Text = "待機狀態"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.turn2)
        Me.GroupBox9.Controls.Add(Me.Label79)
        Me.GroupBox9.Controls.Add(Me.Label33)
        Me.GroupBox9.Controls.Add(Me.Label9)
        Me.GroupBox9.Controls.Add(Me.motor2)
        Me.GroupBox9.Controls.Add(Me.Label24)
        Me.GroupBox9.Controls.Add(Me.up2)
        Me.GroupBox9.Controls.Add(Me.down2)
        Me.GroupBox9.Location = New System.Drawing.Point(360, 273)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(200, 153)
        Me.GroupBox9.TabIndex = 9
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "機台狀況"
        '
        'turn2
        '
        Me.turn2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.turn2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.turn2.Location = New System.Drawing.Point(112, 26)
        Me.turn2.Name = "turn2"
        Me.turn2.Size = New System.Drawing.Size(77, 23)
        Me.turn2.TabIndex = 3
        '
        'Label79
        '
        Me.Label79.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label79.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label79.Location = New System.Drawing.Point(9, 119)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(98, 23)
        Me.Label79.TabIndex = 1
        Me.Label79.Text = "輸送帶馬達"
        '
        'Label33
        '
        Me.Label33.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label33.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label33.Location = New System.Drawing.Point(8, 87)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(98, 23)
        Me.Label33.TabIndex = 6
        Me.Label33.Text = "品檢下降"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label9.Location = New System.Drawing.Point(8, 27)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(98, 23)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "直進旋轉"
        '
        'motor2
        '
        Me.motor2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.motor2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.motor2.Location = New System.Drawing.Point(113, 117)
        Me.motor2.Name = "motor2"
        Me.motor2.Size = New System.Drawing.Size(77, 23)
        Me.motor2.TabIndex = 1
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label24.Location = New System.Drawing.Point(8, 57)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(98, 23)
        Me.Label24.TabIndex = 6
        Me.Label24.Text = "品檢上升"
        '
        'up2
        '
        Me.up2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.up2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.up2.Location = New System.Drawing.Point(112, 57)
        Me.up2.Name = "up2"
        Me.up2.Size = New System.Drawing.Size(77, 23)
        Me.up2.TabIndex = 5
        '
        'down2
        '
        Me.down2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.down2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.down2.Location = New System.Drawing.Point(112, 87)
        Me.down2.Name = "down2"
        Me.down2.Size = New System.Drawing.Size(77, 23)
        Me.down2.TabIndex = 5
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label39)
        Me.GroupBox3.Controls.Add(Me.Label37)
        Me.GroupBox3.Controls.Add(Me.Label35)
        Me.GroupBox3.Controls.Add(Me.SC2)
        Me.GroupBox3.Controls.Add(Me.ST2)
        Me.GroupBox3.Controls.Add(Me.SA2)
        Me.GroupBox3.Controls.Add(Me.SS2)
        Me.GroupBox3.Controls.Add(Me.Label70)
        Me.GroupBox3.Location = New System.Drawing.Point(354, 78)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(206, 153)
        Me.GroupBox3.TabIndex = 7
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "感測狀態"
        '
        'Label39
        '
        Me.Label39.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label39.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label39.Location = New System.Drawing.Point(13, 25)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(80, 23)
        Me.Label39.TabIndex = 1
        Me.Label39.Text = "震動指數"
        '
        'Label37
        '
        Me.Label37.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label37.Location = New System.Drawing.Point(13, 55)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(80, 23)
        Me.Label37.TabIndex = 1
        Me.Label37.Text = "物件數量"
        '
        'Label35
        '
        Me.Label35.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label35.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label35.Location = New System.Drawing.Point(13, 86)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(80, 23)
        Me.Label35.TabIndex = 1
        Me.Label35.Text = "機台溫度"
        '
        'SC2
        '
        Me.SC2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SC2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SC2.Location = New System.Drawing.Point(99, 55)
        Me.SC2.Name = "SC2"
        Me.SC2.Size = New System.Drawing.Size(96, 23)
        Me.SC2.TabIndex = 1
        '
        'ST2
        '
        Me.ST2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ST2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ST2.Location = New System.Drawing.Point(99, 86)
        Me.ST2.Name = "ST2"
        Me.ST2.Size = New System.Drawing.Size(96, 23)
        Me.ST2.TabIndex = 1
        '
        'SA2
        '
        Me.SA2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SA2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SA2.Location = New System.Drawing.Point(99, 116)
        Me.SA2.Name = "SA2"
        Me.SA2.Size = New System.Drawing.Size(96, 23)
        Me.SA2.TabIndex = 1
        '
        'SS2
        '
        Me.SS2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SS2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SS2.Location = New System.Drawing.Point(99, 25)
        Me.SS2.Name = "SS2"
        Me.SS2.Size = New System.Drawing.Size(96, 23)
        Me.SS2.TabIndex = 1
        '
        'Label70
        '
        Me.Label70.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label70.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label70.Location = New System.Drawing.Point(13, 116)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(80, 23)
        Me.Label70.TabIndex = 1
        Me.Label70.Text = "機台電流"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(152, 37)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 33)
        Me.TextBox2.TabIndex = 6
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(150, 231)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(133, 39)
        Me.Button7.TabIndex = 2
        Me.Button7.Text = "紀錄資料"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label28.Font = New System.Drawing.Font("新細明體", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label28.Location = New System.Drawing.Point(37, 37)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(109, 29)
        Me.Label28.TabIndex = 3
        Me.Label28.Text = "工單件數"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Yellow
        Me.GroupBox1.Controls.Add(Me.Label52)
        Me.GroupBox1.Controls.Add(Me.Label42)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label29)
        Me.GroupBox1.Controls.Add(Me.GroupBox11)
        Me.GroupBox1.Controls.Add(Me.PD1)
        Me.GroupBox1.Controls.Add(Me.noc1)
        Me.GroupBox1.Controls.Add(Me.GroupBox10)
        Me.GroupBox1.Controls.Add(Me.GroupBox12)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Controls.Add(Me.Label63)
        Me.GroupBox1.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(27, 86)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(300, 478)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "機台1"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(619, 313)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(120, 34)
        Me.Label52.TabIndex = 12
        Me.Label52.Text = "Label52"
        '
        'Label42
        '
        Me.Label42.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label42.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label42.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label42.Location = New System.Drawing.Point(308, 433)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(126, 35)
        Me.Label42.TabIndex = 1
        Me.Label42.Text = "PD2"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label14.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label14.Location = New System.Drawing.Point(431, 362)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(126, 35)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "PD1"
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label11.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label11.Location = New System.Drawing.Point(566, 366)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(126, 35)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "不良品"
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label29.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label29.Location = New System.Drawing.Point(440, 436)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(126, 35)
        Me.Label29.TabIndex = 1
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.SS1)
        Me.GroupBox11.Controls.Add(Me.Label4)
        Me.GroupBox11.Controls.Add(Me.SA1)
        Me.GroupBox11.Controls.Add(Me.Label5)
        Me.GroupBox11.Controls.Add(Me.Label68)
        Me.GroupBox11.Controls.Add(Me.Label6)
        Me.GroupBox11.Controls.Add(Me.SC1)
        Me.GroupBox11.Controls.Add(Me.ST1)
        Me.GroupBox11.Location = New System.Drawing.Point(377, 195)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(242, 153)
        Me.GroupBox11.TabIndex = 10
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "感測狀態"
        '
        'SS1
        '
        Me.SS1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SS1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SS1.Location = New System.Drawing.Point(122, 25)
        Me.SS1.Name = "SS1"
        Me.SS1.Size = New System.Drawing.Size(106, 23)
        Me.SS1.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Font = New System.Drawing.Font("新細明體", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label4.Location = New System.Drawing.Point(12, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(99, 23)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "震動指數"
        '
        'SA1
        '
        Me.SA1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SA1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SA1.Location = New System.Drawing.Point(122, 122)
        Me.SA1.Name = "SA1"
        Me.SA1.Size = New System.Drawing.Size(106, 23)
        Me.SA1.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Font = New System.Drawing.Font("新細明體", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label5.Location = New System.Drawing.Point(13, 57)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 23)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "物件數量"
        '
        'Label68
        '
        Me.Label68.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label68.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label68.Font = New System.Drawing.Font("新細明體", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label68.Location = New System.Drawing.Point(13, 122)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(98, 23)
        Me.Label68.TabIndex = 1
        Me.Label68.Text = "機台電流"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Font = New System.Drawing.Font("新細明體", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label6.Location = New System.Drawing.Point(13, 90)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(98, 23)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "機台溫度"
        '
        'SC1
        '
        Me.SC1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SC1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SC1.Location = New System.Drawing.Point(122, 57)
        Me.SC1.Name = "SC1"
        Me.SC1.Size = New System.Drawing.Size(106, 23)
        Me.SC1.TabIndex = 1
        '
        'ST1
        '
        Me.ST1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ST1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ST1.Location = New System.Drawing.Point(122, 90)
        Me.ST1.Name = "ST1"
        Me.ST1.Size = New System.Drawing.Size(106, 23)
        Me.ST1.TabIndex = 1
        '
        'PD1
        '
        Me.PD1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.PD1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PD1.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.PD1.Location = New System.Drawing.Point(428, 397)
        Me.PD1.Name = "PD1"
        Me.PD1.Size = New System.Drawing.Size(126, 35)
        Me.PD1.TabIndex = 1
        '
        'noc1
        '
        Me.noc1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.noc1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.noc1.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.noc1.Location = New System.Drawing.Point(566, 403)
        Me.noc1.Name = "noc1"
        Me.noc1.Size = New System.Drawing.Size(126, 35)
        Me.noc1.TabIndex = 1
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.Label1)
        Me.GroupBox10.Controls.Add(Me.Label2)
        Me.GroupBox10.Controls.Add(Me.name1)
        Me.GroupBox10.Controls.Add(Me.Label3)
        Me.GroupBox10.Controls.Add(Me.status1)
        Me.GroupBox10.Controls.Add(Me.number1)
        Me.GroupBox10.Controls.Add(Me.Label76)
        Me.GroupBox10.Controls.Add(Me.Manager1)
        Me.GroupBox10.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.GroupBox10.Location = New System.Drawing.Point(9, 274)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(277, 197)
        Me.GroupBox10.TabIndex = 9
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "機台履歷"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label1.Location = New System.Drawing.Point(11, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(126, 35)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "區域顯示"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label2.Location = New System.Drawing.Point(11, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(126, 35)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "工件名稱"
        '
        'name1
        '
        Me.name1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.name1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.name1.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.name1.Location = New System.Drawing.Point(144, 33)
        Me.name1.Name = "name1"
        Me.name1.Size = New System.Drawing.Size(126, 35)
        Me.name1.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label3.Location = New System.Drawing.Point(11, 112)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(126, 35)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "管理者"
        '
        'status1
        '
        Me.status1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.status1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.status1.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.status1.Location = New System.Drawing.Point(144, 152)
        Me.status1.Name = "status1"
        Me.status1.Size = New System.Drawing.Size(126, 35)
        Me.status1.TabIndex = 1
        Me.status1.Text = "待機狀態"
        '
        'number1
        '
        Me.number1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.number1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.number1.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.number1.Location = New System.Drawing.Point(144, 72)
        Me.number1.Name = "number1"
        Me.number1.Size = New System.Drawing.Size(126, 35)
        Me.number1.TabIndex = 1
        '
        'Label76
        '
        Me.Label76.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label76.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label76.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label76.Location = New System.Drawing.Point(11, 152)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(126, 35)
        Me.Label76.TabIndex = 1
        Me.Label76.Text = "狀態顯示"
        '
        'Manager1
        '
        Me.Manager1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Manager1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Manager1.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Manager1.Location = New System.Drawing.Point(144, 112)
        Me.Manager1.Name = "Manager1"
        Me.Manager1.Size = New System.Drawing.Size(126, 35)
        Me.Manager1.TabIndex = 1
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.turn1)
        Me.GroupBox12.Controls.Add(Me.Label27)
        Me.GroupBox12.Controls.Add(Me.Label36)
        Me.GroupBox12.Controls.Add(Me.Label7)
        Me.GroupBox12.Controls.Add(Me.motor1)
        Me.GroupBox12.Controls.Add(Me.up1)
        Me.GroupBox12.Controls.Add(Me.Label34)
        Me.GroupBox12.Controls.Add(Me.down1)
        Me.GroupBox12.Location = New System.Drawing.Point(377, 41)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(245, 150)
        Me.GroupBox12.TabIndex = 11
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "機台狀態"
        '
        'turn1
        '
        Me.turn1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.turn1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.turn1.Location = New System.Drawing.Point(140, 23)
        Me.turn1.Name = "turn1"
        Me.turn1.Size = New System.Drawing.Size(99, 23)
        Me.turn1.TabIndex = 3
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label27.Location = New System.Drawing.Point(13, 23)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(120, 23)
        Me.Label27.TabIndex = 4
        Me.Label27.Text = "直進旋轉"
        '
        'Label36
        '
        Me.Label36.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label36.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label36.Location = New System.Drawing.Point(12, 55)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(120, 23)
        Me.Label36.TabIndex = 6
        Me.Label36.Text = "品檢下降"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Font = New System.Drawing.Font("新細明體", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label7.Location = New System.Drawing.Point(13, 120)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(120, 23)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "輸送帶馬達"
        '
        'motor1
        '
        Me.motor1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.motor1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.motor1.Location = New System.Drawing.Point(141, 120)
        Me.motor1.Name = "motor1"
        Me.motor1.Size = New System.Drawing.Size(99, 23)
        Me.motor1.TabIndex = 1
        '
        'up1
        '
        Me.up1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.up1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.up1.Location = New System.Drawing.Point(141, 87)
        Me.up1.Name = "up1"
        Me.up1.Size = New System.Drawing.Size(99, 23)
        Me.up1.TabIndex = 5
        '
        'Label34
        '
        Me.Label34.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label34.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label34.Location = New System.Drawing.Point(13, 87)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(120, 23)
        Me.Label34.TabIndex = 6
        Me.Label34.Text = "品檢上升"
        '
        'down1
        '
        Me.down1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.down1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.down1.Location = New System.Drawing.Point(140, 55)
        Me.down1.Name = "down1"
        Me.down1.Size = New System.Drawing.Size(99, 23)
        Me.down1.TabIndex = 5
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Button6.Location = New System.Drawing.Point(153, 230)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(133, 39)
        Me.Button6.TabIndex = 8
        Me.Button6.Text = "紀錄資料"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(135, 35)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 48)
        Me.TextBox1.TabIndex = 6
        '
        'PictureBox1
        '
        Me.PictureBox1.ErrorImage = CType(resources.GetObject("PictureBox1.ErrorImage"), System.Drawing.Image)
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(9, 81)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(277, 147)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label63
        '
        Me.Label63.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label63.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label63.Font = New System.Drawing.Font("新細明體", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label63.Location = New System.Drawing.Point(20, 35)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(109, 33)
        Me.Label63.TabIndex = 3
        Me.Label63.Text = "工單件數"
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(6, 41)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(133, 36)
        Me.Button9.TabIndex = 9
        Me.Button9.Text = "啟動機台"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(145, 41)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(133, 36)
        Me.Button10.TabIndex = 10
        Me.Button10.Text = "緊急停止"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(284, 41)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(133, 34)
        Me.Button11.TabIndex = 12
        Me.Button11.Text = "緊急復歸"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox7.Controls.Add(Me.Button4)
        Me.GroupBox7.Controls.Add(Me.ComboBox2)
        Me.GroupBox7.Controls.Add(Me.Label60)
        Me.GroupBox7.Controls.Add(Me.PD2333)
        Me.GroupBox7.Controls.Add(Me.Label59)
        Me.GroupBox7.Controls.Add(Me.Label61)
        Me.GroupBox7.Controls.Add(Me.TextBox4)
        Me.GroupBox7.Controls.Add(Me.Button11)
        Me.GroupBox7.Controls.Add(Me.Label12)
        Me.GroupBox7.Controls.Add(Me.Button10)
        Me.GroupBox7.Controls.Add(Me.Button9)
        Me.GroupBox7.Controls.Add(Me.GroupBox1)
        Me.GroupBox7.Controls.Add(Me.GroupBox5)
        Me.GroupBox7.Controls.Add(Me.GroupBox6)
        Me.GroupBox7.Font = New System.Drawing.Font("新細明體", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(274, 2)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(955, 608)
        Me.GroupBox7.TabIndex = 8
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "A場域機台"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(796, 42)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(104, 35)
        Me.Button4.TabIndex = 18
        Me.Button4.Text = "分配"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"螺絲", "螺帽", "滾珠螺桿", "沖模", "印件"})
        Me.ComboBox2.Location = New System.Drawing.Point(423, 40)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(145, 42)
        Me.ComboBox2.TabIndex = 17
        Me.ComboBox2.Text = "選擇工件"
        '
        'Label60
        '
        Me.Label60.BackColor = System.Drawing.Color.LightGreen
        Me.Label60.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label60.Location = New System.Drawing.Point(323, 568)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(129, 34)
        Me.Label60.TabIndex = 15
        Me.Label60.Text = "綠色:正常狀態"
        '
        'PD2333
        '
        Me.PD2333.BackColor = System.Drawing.Color.Red
        Me.PD2333.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PD2333.Location = New System.Drawing.Point(593, 568)
        Me.PD2333.Name = "PD2333"
        Me.PD2333.Size = New System.Drawing.Size(129, 34)
        Me.PD2333.TabIndex = 13
        Me.PD2333.Text = "紅色:危險狀態"
        '
        'Label59
        '
        Me.Label59.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label59.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label59.Location = New System.Drawing.Point(458, 568)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(129, 34)
        Me.Label59.TabIndex = 14
        Me.Label59.Text = "橙色:警告狀態"
        '
        'Label61
        '
        Me.Label61.BackColor = System.Drawing.Color.Yellow
        Me.Label61.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label61.Location = New System.Drawing.Point(188, 568)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(129, 34)
        Me.Label61.TabIndex = 16
        Me.Label61.Text = "黃色:待機狀態"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(689, 42)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 33)
        Me.TextBox4.TabIndex = 6
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label12.Font = New System.Drawing.Font("新細明體", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label12.Location = New System.Drawing.Point(574, 42)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(109, 33)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "工單總數"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer4
        '
        '
        'Timer5
        '
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(12, 613)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(69, 20)
        Me.Label54.TabIndex = 19
        Me.Label54.Text = "未輪播"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1241, 660)
        Me.Controls.Add(Me.Label54)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox2)
        Me.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox15.ResumeLayout(False)
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox14.ResumeLayout(False)
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox12.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Label30 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents ec As Label
    Friend WithEvents ev As Label
    Friend WithEvents ef As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents et As Label
    Friend WithEvents eh As Label
    Friend WithEvents Label66 As Label
    Friend WithEvents el As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents Timer2 As Timer
    Friend WithEvents turn3 As Label
    Friend WithEvents te As Label
    Friend WithEvents Button12 As Button
    Friend WithEvents Timer3 As Timer
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents Label31 As Label
    Friend WithEvents GroupBox15 As GroupBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents turn As Label
    Friend WithEvents up3 As Label
    Friend WithEvents motor3 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents down3 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents GroupBox14 As GroupBox
    Friend WithEvents SS3 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents SA3 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents SC3 As Label
    Friend WithEvents Label72 As Label
    Friend WithEvents ST3 As Label
    Friend WithEvents Button8 As Button
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents GroupBox13 As GroupBox
    Friend WithEvents nama3 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents number3 As Label
    Friend WithEvents status3 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents manager3 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents nama2 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents number2 As Label
    Friend WithEvents manager2 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents status2 As Label
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents turn2 As Label
    Friend WithEvents Label79 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents motor2 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents up2 As Label
    Friend WithEvents down2 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label39 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents SC2 As Label
    Friend WithEvents ST2 As Label
    Friend WithEvents SA2 As Label
    Friend WithEvents SS2 As Label
    Friend WithEvents Label70 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Button7 As Button
    Friend WithEvents Label28 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox11 As GroupBox
    Friend WithEvents SS1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents SA1 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label68 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents SC1 As Label
    Friend WithEvents ST1 As Label
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents name1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents status1 As Label
    Friend WithEvents number1 As Label
    Friend WithEvents Label76 As Label
    Friend WithEvents Manager1 As Label
    Friend WithEvents GroupBox12 As GroupBox
    Friend WithEvents turn1 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents motor1 As Label
    Friend WithEvents up1 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents down1 As Label
    Friend WithEvents Button6 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label63 As Label
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents Label60 As Label
    Friend WithEvents PD2333 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents Button4 As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents noc1 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents PD1 As Label
    Friend WithEvents Timer4 As Timer
    Friend WithEvents Label50 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Timer5 As Timer
    Friend WithEvents Button2 As Button
    Friend WithEvents Label54 As Label
End Class
