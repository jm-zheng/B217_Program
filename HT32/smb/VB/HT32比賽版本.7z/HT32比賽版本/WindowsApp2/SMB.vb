﻿Public Class SMB
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        DataGridView1.Rows.Add(Label5.Text, Label6.Text, Label7.Text, Label7.Text)
    End Sub
End Class
