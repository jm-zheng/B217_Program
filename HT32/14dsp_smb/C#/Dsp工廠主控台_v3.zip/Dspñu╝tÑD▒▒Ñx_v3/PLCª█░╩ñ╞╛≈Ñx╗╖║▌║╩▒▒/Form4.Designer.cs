﻿namespace PLC自動化機台遠端監控
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lab_m3_open = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lab_m3_m_z = new System.Windows.Forms.Label();
            this.lab_m3_m_y = new System.Windows.Forms.Label();
            this.lab_m3_m_x = new System.Windows.Forms.Label();
            this.lab_m3_mode = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.lab_m3_status = new System.Windows.Forms.Label();
            this.lab_m3_user = new System.Windows.Forms.Label();
            this.lab_m3_work = new System.Windows.Forms.Label();
            this.lab_m3_region = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.m3_mqtt_timer = new System.Windows.Forms.Timer(this.components);
            this.m3_status_timer = new System.Windows.Forms.Timer(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button2 = new System.Windows.Forms.Button();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Yellow;
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(668, 598);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "CNC銑床";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(512, 52);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 38);
            this.button1.TabIndex = 60;
            this.button1.Text = "紀錄資料";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.White;
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label29.Location = new System.Drawing.Point(160, 51);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(125, 40);
            this.label29.TabIndex = 61;
            this.label29.Text = "       ";
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label23.Location = new System.Drawing.Point(12, 51);
            this.label23.Name = "label23";
            this.label23.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label23.Size = new System.Drawing.Size(136, 40);
            this.label23.TabIndex = 60;
            this.label23.Text = "工單件數";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.lab_m3_open);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.lab_m3_m_z);
            this.groupBox2.Controls.Add(this.lab_m3_m_y);
            this.groupBox2.Controls.Add(this.lab_m3_m_x);
            this.groupBox2.Controls.Add(this.lab_m3_mode);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Location = new System.Drawing.Point(15, 352);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(641, 240);
            this.groupBox2.TabIndex = 48;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "機台狀況";
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.Aqua;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label19.Location = new System.Drawing.Point(495, 190);
            this.label19.Name = "label19";
            this.label19.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label19.Size = new System.Drawing.Size(136, 40);
            this.label19.TabIndex = 41;
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Aqua;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label17.Location = new System.Drawing.Point(495, 138);
            this.label17.Name = "label17";
            this.label17.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label17.Size = new System.Drawing.Size(136, 40);
            this.label17.TabIndex = 43;
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_m3_open
            // 
            this.lab_m3_open.BackColor = System.Drawing.Color.Aqua;
            this.lab_m3_open.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_m3_open.Location = new System.Drawing.Point(495, 29);
            this.lab_m3_open.Name = "lab_m3_open";
            this.lab_m3_open.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_m3_open.Size = new System.Drawing.Size(136, 40);
            this.lab_m3_open.TabIndex = 44;
            this.lab_m3_open.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Aqua;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label18.Location = new System.Drawing.Point(495, 82);
            this.label18.Name = "label18";
            this.label18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label18.Size = new System.Drawing.Size(136, 40);
            this.label18.TabIndex = 42;
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Aqua;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label14.Location = new System.Drawing.Point(333, 138);
            this.label14.Name = "label14";
            this.label14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label14.Size = new System.Drawing.Size(157, 40);
            this.label14.TabIndex = 46;
            this.label14.Text = "機台溫度";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Aqua;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label13.Location = new System.Drawing.Point(333, 29);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label13.Size = new System.Drawing.Size(157, 40);
            this.label13.TabIndex = 47;
            this.label13.Text = "開機時間";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.Aqua;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label20.Location = new System.Drawing.Point(333, 190);
            this.label20.Name = "label20";
            this.label20.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label20.Size = new System.Drawing.Size(157, 40);
            this.label20.TabIndex = 40;
            this.label20.Text = "震動指數";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.Aqua;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label15.Location = new System.Drawing.Point(333, 82);
            this.label15.Name = "label15";
            this.label15.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label15.Size = new System.Drawing.Size(157, 40);
            this.label15.TabIndex = 45;
            this.label15.Text = "物件數量";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Aqua;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(9, 190);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(157, 40);
            this.label4.TabIndex = 47;
            this.label4.Text = "機械座標Z軸";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Aqua;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Location = new System.Drawing.Point(9, 138);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(157, 40);
            this.label5.TabIndex = 46;
            this.label5.Text = "機械座標Y軸";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Aqua;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label6.Location = new System.Drawing.Point(9, 82);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label6.Size = new System.Drawing.Size(157, 40);
            this.label6.TabIndex = 45;
            this.label6.Text = "機械座標X軸";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_m3_m_z
            // 
            this.lab_m3_m_z.BackColor = System.Drawing.Color.Aqua;
            this.lab_m3_m_z.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_m3_m_z.Location = new System.Drawing.Point(173, 190);
            this.lab_m3_m_z.Name = "lab_m3_m_z";
            this.lab_m3_m_z.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_m3_m_z.Size = new System.Drawing.Size(136, 40);
            this.lab_m3_m_z.TabIndex = 44;
            this.lab_m3_m_z.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_m3_m_y
            // 
            this.lab_m3_m_y.BackColor = System.Drawing.Color.Aqua;
            this.lab_m3_m_y.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_m3_m_y.Location = new System.Drawing.Point(173, 138);
            this.lab_m3_m_y.Name = "lab_m3_m_y";
            this.lab_m3_m_y.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_m3_m_y.Size = new System.Drawing.Size(136, 40);
            this.lab_m3_m_y.TabIndex = 43;
            this.lab_m3_m_y.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_m3_m_x
            // 
            this.lab_m3_m_x.BackColor = System.Drawing.Color.Aqua;
            this.lab_m3_m_x.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_m3_m_x.Location = new System.Drawing.Point(173, 82);
            this.lab_m3_m_x.Name = "lab_m3_m_x";
            this.lab_m3_m_x.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_m3_m_x.Size = new System.Drawing.Size(136, 40);
            this.lab_m3_m_x.TabIndex = 42;
            this.lab_m3_m_x.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_m3_mode
            // 
            this.lab_m3_mode.BackColor = System.Drawing.Color.Aqua;
            this.lab_m3_mode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_m3_mode.Location = new System.Drawing.Point(173, 29);
            this.lab_m3_mode.Name = "lab_m3_mode";
            this.lab_m3_mode.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_m3_mode.Size = new System.Drawing.Size(136, 40);
            this.lab_m3_mode.TabIndex = 41;
            this.lab_m3_mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Aqua;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label12.Location = new System.Drawing.Point(9, 29);
            this.label12.Name = "label12";
            this.label12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label12.Size = new System.Drawing.Size(157, 40);
            this.label12.TabIndex = 40;
            this.label12.Text = "模式";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox5
            // 
            this.groupBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox5.Controls.Add(this.label37);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.lab_m3_status);
            this.groupBox5.Controls.Add(this.lab_m3_user);
            this.groupBox5.Controls.Add(this.lab_m3_work);
            this.groupBox5.Controls.Add(this.lab_m3_region);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Location = new System.Drawing.Point(339, 98);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Size = new System.Drawing.Size(317, 240);
            this.groupBox5.TabIndex = 42;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "機台履歷";
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.Aqua;
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label37.Location = new System.Drawing.Point(9, 190);
            this.label37.Name = "label37";
            this.label37.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label37.Size = new System.Drawing.Size(157, 40);
            this.label37.TabIndex = 47;
            this.label37.Text = "狀態顯示";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.Aqua;
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label36.Location = new System.Drawing.Point(9, 138);
            this.label36.Name = "label36";
            this.label36.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label36.Size = new System.Drawing.Size(157, 40);
            this.label36.TabIndex = 46;
            this.label36.Text = "使用者";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.Aqua;
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label35.Location = new System.Drawing.Point(9, 82);
            this.label35.Name = "label35";
            this.label35.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label35.Size = new System.Drawing.Size(157, 40);
            this.label35.TabIndex = 45;
            this.label35.Text = "工件名稱";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lab_m3_status
            // 
            this.lab_m3_status.BackColor = System.Drawing.Color.Aqua;
            this.lab_m3_status.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_m3_status.Location = new System.Drawing.Point(173, 190);
            this.lab_m3_status.Name = "lab_m3_status";
            this.lab_m3_status.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_m3_status.Size = new System.Drawing.Size(136, 40);
            this.lab_m3_status.TabIndex = 44;
            this.lab_m3_status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_m3_user
            // 
            this.lab_m3_user.BackColor = System.Drawing.Color.Aqua;
            this.lab_m3_user.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_m3_user.Location = new System.Drawing.Point(173, 138);
            this.lab_m3_user.Name = "lab_m3_user";
            this.lab_m3_user.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_m3_user.Size = new System.Drawing.Size(136, 40);
            this.lab_m3_user.TabIndex = 43;
            this.lab_m3_user.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_m3_work
            // 
            this.lab_m3_work.BackColor = System.Drawing.Color.Aqua;
            this.lab_m3_work.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_m3_work.Location = new System.Drawing.Point(175, 82);
            this.lab_m3_work.Name = "lab_m3_work";
            this.lab_m3_work.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_m3_work.Size = new System.Drawing.Size(136, 40);
            this.lab_m3_work.TabIndex = 42;
            this.lab_m3_work.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_m3_region
            // 
            this.lab_m3_region.BackColor = System.Drawing.Color.Aqua;
            this.lab_m3_region.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_m3_region.Location = new System.Drawing.Point(173, 29);
            this.lab_m3_region.Name = "lab_m3_region";
            this.lab_m3_region.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_m3_region.Size = new System.Drawing.Size(136, 40);
            this.lab_m3_region.TabIndex = 41;
            this.lab_m3_region.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Aqua;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.Location = new System.Drawing.Point(9, 29);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label11.Size = new System.Drawing.Size(157, 40);
            this.label11.TabIndex = 40;
            this.label11.Text = "區域顯示";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PLC自動化機台遠端監控.Properties.Resources.list_11939737600;
            this.pictureBox1.Location = new System.Drawing.Point(12, 112);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(320, 225);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button3.Location = new System.Drawing.Point(351, 623);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(101, 38);
            this.button3.TabIndex = 62;
            this.button3.Text = "啟動";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // m3_mqtt_timer
            // 
            this.m3_mqtt_timer.Interval = 1000;
            this.m3_mqtt_timer.Tick += new System.EventHandler(this.m3_mqtt_timer_Tick);
            // 
            // m3_status_timer
            // 
            this.m3_status_timer.Tick += new System.EventHandler(this.m3_status_timer_Tick);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dataGridView1.Location = new System.Drawing.Point(683, 124);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(655, 179);
            this.dataGridView1.TabIndex = 63;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11});
            this.dataGridView2.Location = new System.Drawing.Point(686, 329);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 27;
            this.dataGridView2.Size = new System.Drawing.Size(590, 157);
            this.dataGridView2.TabIndex = 64;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column7.HeaderText = "模式";
            this.Column7.Name = "Column7";
            this.Column7.Width = 66;
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column8.HeaderText = "機械座標X";
            this.Column8.Name = "Column8";
            this.Column8.Width = 106;
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column9.HeaderText = "機械座標Y";
            this.Column9.Name = "Column9";
            this.Column9.Width = 106;
            // 
            // Column10
            // 
            this.Column10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column10.HeaderText = "機械座標Z";
            this.Column10.Name = "Column10";
            this.Column10.Width = 105;
            // 
            // Column11
            // 
            this.Column11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column11.HeaderText = "開機時間";
            this.Column11.Name = "Column11";
            this.Column11.Width = 96;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(200, 637);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 65;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column1.HeaderText = "日期";
            this.Column1.Name = "Column1";
            this.Column1.Width = 66;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "時間";
            this.Column2.Name = "Column2";
            this.Column2.Width = 86;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column3.HeaderText = "區域顯示";
            this.Column3.Name = "Column3";
            this.Column3.Width = 96;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column4.HeaderText = "工件名稱";
            this.Column4.Name = "Column4";
            this.Column4.Width = 96;
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column5.HeaderText = "使用者";
            this.Column5.Name = "Column5";
            this.Column5.Width = 81;
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column6.HeaderText = "狀態顯示";
            this.Column6.Name = "Column6";
            this.Column6.Width = 96;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1542, 691);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lab_m3_open;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lab_m3_m_z;
        private System.Windows.Forms.Label lab_m3_m_y;
        private System.Windows.Forms.Label lab_m3_m_x;
        private System.Windows.Forms.Label lab_m3_mode;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        public System.Windows.Forms.Label lab_m3_status;
        public System.Windows.Forms.Label lab_m3_user;
        public System.Windows.Forms.Label lab_m3_work;
        public System.Windows.Forms.Label lab_m3_region;
        private System.Windows.Forms.Timer m3_mqtt_timer;
        private System.Windows.Forms.Timer m3_status_timer;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
    }
}