﻿namespace PLC自動化機台遠端監控
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lab_time = new System.Windows.Forms.Label();
            this.lab_data = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lab_el = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lab_ev = new System.Windows.Forms.Label();
            this.lab_ef = new System.Windows.Forms.Label();
            this.lab_ec = new System.Windows.Forms.Label();
            this.lab_eh = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lab_et = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.lab_sc2_sno = new System.Windows.Forms.Label();
            this.lab_sp2 = new System.Windows.Forms.Label();
            this.lab_ss2 = new System.Windows.Forms.Label();
            this.lab_sc2_pno = new System.Windows.Forms.Label();
            this.lab_sc2_pok = new System.Windows.Forms.Label();
            this.lab_sc2_sok = new System.Windows.Forms.Label();
            this.lab_st2 = new System.Windows.Forms.Label();
            this.lab_sa2 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.label49 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.lab_m3_status = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.lab_Machine_status = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.lab_sa1 = new System.Windows.Forms.Label();
            this.lab_sc1_pno = new System.Windows.Forms.Label();
            this.lab_sc1_sno = new System.Windows.Forms.Label();
            this.lab_sc1_pok = new System.Windows.Forms.Label();
            this.lab_motor = new System.Windows.Forms.Label();
            this.lab_sc1_sok = new System.Windows.Forms.Label();
            this.lab_sp1 = new System.Windows.Forms.Label();
            this.lab_st1 = new System.Windows.Forms.Label();
            this.lab_ss1 = new System.Windows.Forms.Label();
            this.lab_down = new System.Windows.Forms.Label();
            this.lab_down_c = new System.Windows.Forms.Label();
            this.lab_trun_c = new System.Windows.Forms.Label();
            this.lab_up_c = new System.Windows.Forms.Label();
            this.lab_up = new System.Windows.Forms.Label();
            this.lab_trun = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.lab_time);
            this.groupBox1.Controls.Add(this.lab_data);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(8, 12);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(331, 686);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "智慧工廠機上盒";
            // 
            // lab_time
            // 
            this.lab_time.BackColor = System.Drawing.Color.Silver;
            this.lab_time.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_time.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_time.Location = new System.Drawing.Point(112, 267);
            this.lab_time.Name = "lab_time";
            this.lab_time.Size = new System.Drawing.Size(189, 30);
            this.lab_time.TabIndex = 33;
            this.lab_time.Text = "         ";
            this.lab_time.Click += new System.EventHandler(this.label5_Click);
            // 
            // lab_data
            // 
            this.lab_data.BackColor = System.Drawing.Color.Silver;
            this.lab_data.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_data.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_data.Location = new System.Drawing.Point(112, 228);
            this.lab_data.Name = "lab_data";
            this.lab_data.Size = new System.Drawing.Size(189, 30);
            this.lab_data.TabIndex = 31;
            this.lab_data.Text = "         ";
            this.lab_data.Click += new System.EventHandler(this.label4_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.lab_el);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.lab_ev);
            this.groupBox3.Controls.Add(this.lab_ef);
            this.groupBox3.Controls.Add(this.lab_ec);
            this.groupBox3.Controls.Add(this.lab_eh);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.lab_et);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox3.Location = new System.Drawing.Point(11, 316);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(315, 338);
            this.groupBox3.TabIndex = 32;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "環境感測";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Silver;
            this.button3.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button3.Location = new System.Drawing.Point(5, 268);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(144, 39);
            this.button3.TabIndex = 30;
            this.button3.Text = "上傳資料 ";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Silver;
            this.button2.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.Location = new System.Drawing.Point(169, 268);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(95, 39);
            this.button2.TabIndex = 29;
            this.button2.Text = "輪播  ";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label26.Location = new System.Drawing.Point(264, 155);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(46, 24);
            this.label26.TabIndex = 27;
            this.label26.Text = "ppm";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label25.Location = new System.Drawing.Point(264, 190);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(46, 24);
            this.label25.TabIndex = 26;
            this.label25.Text = "ppm";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label24.Location = new System.Drawing.Point(264, 224);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(46, 24);
            this.label24.TabIndex = 25;
            this.label24.Text = "lux";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label23.Location = new System.Drawing.Point(264, 119);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(46, 24);
            this.label23.TabIndex = 24;
            this.label23.Text = "ppm";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label22.Location = new System.Drawing.Point(264, 84);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(34, 24);
            this.label22.TabIndex = 23;
            this.label22.Text = "度";
            // 
            // lab_el
            // 
            this.lab_el.BackColor = System.Drawing.Color.Aquamarine;
            this.lab_el.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_el.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_el.Location = new System.Drawing.Point(117, 220);
            this.lab_el.Name = "lab_el";
            this.lab_el.Size = new System.Drawing.Size(140, 30);
            this.lab_el.TabIndex = 20;
            this.lab_el.Text = "         ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Silver;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label18.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label18.Location = new System.Drawing.Point(5, 220);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(98, 30);
            this.label18.TabIndex = 19;
            this.label18.Text = "光照度";
            // 
            // lab_ev
            // 
            this.lab_ev.BackColor = System.Drawing.Color.Aquamarine;
            this.lab_ev.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_ev.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_ev.Location = new System.Drawing.Point(117, 186);
            this.lab_ev.Name = "lab_ev";
            this.lab_ev.Size = new System.Drawing.Size(140, 30);
            this.lab_ev.TabIndex = 18;
            this.lab_ev.Text = "         ";
            // 
            // lab_ef
            // 
            this.lab_ef.BackColor = System.Drawing.Color.Aquamarine;
            this.lab_ef.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_ef.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_ef.Location = new System.Drawing.Point(117, 151);
            this.lab_ef.Name = "lab_ef";
            this.lab_ef.Size = new System.Drawing.Size(140, 30);
            this.lab_ef.TabIndex = 17;
            this.lab_ef.Text = "         ";
            // 
            // lab_ec
            // 
            this.lab_ec.BackColor = System.Drawing.Color.Aquamarine;
            this.lab_ec.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_ec.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_ec.Location = new System.Drawing.Point(117, 115);
            this.lab_ec.Name = "lab_ec";
            this.lab_ec.Size = new System.Drawing.Size(140, 30);
            this.lab_ec.TabIndex = 16;
            this.lab_ec.Text = "         ";
            // 
            // lab_eh
            // 
            this.lab_eh.BackColor = System.Drawing.Color.Aquamarine;
            this.lab_eh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_eh.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_eh.Location = new System.Drawing.Point(117, 80);
            this.lab_eh.Name = "lab_eh";
            this.lab_eh.Size = new System.Drawing.Size(140, 30);
            this.lab_eh.TabIndex = 15;
            this.lab_eh.Text = "         ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(264, 49);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 24);
            this.label13.TabIndex = 14;
            this.label13.Text = "度";
            // 
            // lab_et
            // 
            this.lab_et.BackColor = System.Drawing.Color.Aquamarine;
            this.lab_et.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_et.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lab_et.Location = new System.Drawing.Point(117, 45);
            this.lab_et.Name = "lab_et";
            this.lab_et.Size = new System.Drawing.Size(140, 30);
            this.lab_et.TabIndex = 13;
            this.lab_et.Text = "         ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Silver;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(5, 186);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(98, 30);
            this.label11.TabIndex = 12;
            this.label11.Text = "TVOC  ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Silver;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(5, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 30);
            this.label10.TabIndex = 11;
            this.label10.Text = "甲醛  ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Silver;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label9.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(5, 115);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 30);
            this.label9.TabIndex = 10;
            this.label9.Text = "CO2   ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Silver;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(5, 80);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 30);
            this.label8.TabIndex = 9;
            this.label8.Text = "濕度  ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Silver;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(5, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 30);
            this.label7.TabIndex = 8;
            this.label7.Text = "溫度  ";
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label20.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label20.Location = new System.Drawing.Point(12, 96);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(289, 118);
            this.label20.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Silver;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(9, 268);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 30);
            this.label3.TabIndex = 4;
            this.label3.Text = "時間 ";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Silver;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(9, 229);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 30);
            this.label2.TabIndex = 3;
            this.label2.Text = "日期 ";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(236, 50);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(77, 34);
            this.button1.TabIndex = 2;
            this.button1.Text = "搜尋";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(88, 50);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(143, 31);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.Text = "選擇Port";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.label1.Font = new System.Drawing.Font("標楷體", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(11, 52);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(72, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "COM埠";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.UseMnemonic = false;
            this.label1.UseWaitCursor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label27.Location = new System.Drawing.Point(12, 714);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(69, 20);
            this.label27.TabIndex = 28;
            this.label27.Text = "未輪播";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.button13);
            this.groupBox2.Controls.Add(this.button11);
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.groupBox6);
            this.groupBox2.Controls.Add(this.groupBox8);
            this.groupBox2.Controls.Add(this.label62);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.label60);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label59);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.button8);
            this.groupBox2.Controls.Add(this.comboBox2);
            this.groupBox2.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox2.Location = new System.Drawing.Point(333, 12);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(1001, 767);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "A場域機台";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.DodgerBlue;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(168, 701);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(157, 40);
            this.label4.TabIndex = 60;
            this.label4.Text = "藍色:關機";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button13.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button13.Location = new System.Drawing.Point(852, 29);
            this.button13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(148, 66);
            this.button13.TabIndex = 59;
            this.button13.Text = "緊急復歸";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button11.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button11.Location = new System.Drawing.Point(544, 29);
            this.button11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(148, 66);
            this.button11.TabIndex = 33;
            this.button11.Text = "啟動機台";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button4.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button4.Location = new System.Drawing.Point(698, 29);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(148, 66);
            this.button4.TabIndex = 58;
            this.button4.Text = "緊急停止";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.DodgerBlue;
            this.groupBox6.Controls.Add(this.textBox12);
            this.groupBox6.Controls.Add(this.lab_sc2_sno);
            this.groupBox6.Controls.Add(this.lab_sp2);
            this.groupBox6.Controls.Add(this.lab_ss2);
            this.groupBox6.Controls.Add(this.lab_sc2_pno);
            this.groupBox6.Controls.Add(this.lab_sc2_pok);
            this.groupBox6.Controls.Add(this.lab_sc2_sok);
            this.groupBox6.Controls.Add(this.lab_st2);
            this.groupBox6.Controls.Add(this.lab_sa2);
            this.groupBox6.Controls.Add(this.button9);
            this.groupBox6.Controls.Add(this.pictureBox2);
            this.groupBox6.Controls.Add(this.label39);
            this.groupBox6.Controls.Add(this.groupBox7);
            this.groupBox6.Location = new System.Drawing.Point(21, 413);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox6.Size = new System.Drawing.Size(609, 286);
            this.groupBox6.TabIndex = 40;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "多軸複合加工機";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(158, 45);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(123, 40);
            this.textBox12.TabIndex = 71;
            // 
            // lab_sc2_sno
            // 
            this.lab_sc2_sno.BackColor = System.Drawing.Color.Aqua;
            this.lab_sc2_sno.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_sc2_sno.Location = new System.Drawing.Point(319, 347);
            this.lab_sc2_sno.Name = "lab_sc2_sno";
            this.lab_sc2_sno.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_sc2_sno.Size = new System.Drawing.Size(136, 40);
            this.lab_sc2_sno.TabIndex = 70;
            this.lab_sc2_sno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_sp2
            // 
            this.lab_sp2.BackColor = System.Drawing.Color.Aqua;
            this.lab_sp2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_sp2.Location = new System.Drawing.Point(462, 295);
            this.lab_sp2.Name = "lab_sp2";
            this.lab_sp2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_sp2.Size = new System.Drawing.Size(136, 40);
            this.lab_sp2.TabIndex = 69;
            this.lab_sp2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_ss2
            // 
            this.lab_ss2.BackColor = System.Drawing.Color.Aqua;
            this.lab_ss2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_ss2.Location = new System.Drawing.Point(319, 295);
            this.lab_ss2.Name = "lab_ss2";
            this.lab_ss2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_ss2.Size = new System.Drawing.Size(136, 40);
            this.lab_ss2.TabIndex = 68;
            this.lab_ss2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_sc2_pno
            // 
            this.lab_sc2_pno.BackColor = System.Drawing.Color.Aqua;
            this.lab_sc2_pno.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_sc2_pno.Location = new System.Drawing.Point(461, 347);
            this.lab_sc2_pno.Name = "lab_sc2_pno";
            this.lab_sc2_pno.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_sc2_pno.Size = new System.Drawing.Size(136, 40);
            this.lab_sc2_pno.TabIndex = 67;
            this.lab_sc2_pno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_sc2_pok
            // 
            this.lab_sc2_pok.BackColor = System.Drawing.Color.Aqua;
            this.lab_sc2_pok.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_sc2_pok.Location = new System.Drawing.Point(177, 347);
            this.lab_sc2_pok.Name = "lab_sc2_pok";
            this.lab_sc2_pok.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_sc2_pok.Size = new System.Drawing.Size(136, 40);
            this.lab_sc2_pok.TabIndex = 66;
            this.lab_sc2_pok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_sc2_sok
            // 
            this.lab_sc2_sok.BackColor = System.Drawing.Color.Aqua;
            this.lab_sc2_sok.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_sc2_sok.Location = new System.Drawing.Point(31, 347);
            this.lab_sc2_sok.Name = "lab_sc2_sok";
            this.lab_sc2_sok.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_sc2_sok.Size = new System.Drawing.Size(136, 40);
            this.lab_sc2_sok.TabIndex = 65;
            this.lab_sc2_sok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_st2
            // 
            this.lab_st2.BackColor = System.Drawing.Color.Aqua;
            this.lab_st2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_st2.Location = new System.Drawing.Point(31, 295);
            this.lab_st2.Name = "lab_st2";
            this.lab_st2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_st2.Size = new System.Drawing.Size(136, 40);
            this.lab_st2.TabIndex = 64;
            this.lab_st2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_sa2
            // 
            this.lab_sa2.BackColor = System.Drawing.Color.Aqua;
            this.lab_sa2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_sa2.Location = new System.Drawing.Point(177, 295);
            this.lab_sa2.Name = "lab_sa2";
            this.lab_sa2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_sa2.Size = new System.Drawing.Size(136, 40);
            this.lab_sa2.TabIndex = 63;
            this.lab_sa2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.DarkGray;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button9.Location = new System.Drawing.Point(147, 240);
            this.button9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(139, 40);
            this.button9.TabIndex = 38;
            this.button9.Text = "紀錄資料";
            this.button9.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.LightGray;
            this.label39.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label39.Location = new System.Drawing.Point(19, 46);
            this.label39.Name = "label39";
            this.label39.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label39.Size = new System.Drawing.Size(136, 40);
            this.label39.TabIndex = 1;
            this.label39.Text = "工單件數";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.groupBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox7.Controls.Add(this.textBox3);
            this.groupBox7.Controls.Add(this.textBox2);
            this.groupBox7.Controls.Add(this.textBox1);
            this.groupBox7.Controls.Add(this.label40);
            this.groupBox7.Controls.Add(this.label41);
            this.groupBox7.Controls.Add(this.label42);
            this.groupBox7.Controls.Add(this.label43);
            this.groupBox7.Controls.Add(this.label47);
            this.groupBox7.Location = new System.Drawing.Point(297, 33);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Size = new System.Drawing.Size(300, 240);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "機台履歷";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.Cyan;
            this.textBox3.Location = new System.Drawing.Point(154, 142);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(137, 40);
            this.textBox3.TabIndex = 50;
            this.textBox3.Text = "鍾志勳";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.Cyan;
            this.textBox2.Location = new System.Drawing.Point(154, 94);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(137, 40);
            this.textBox2.TabIndex = 49;
            this.textBox2.Text = "5號工件";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Cyan;
            this.textBox1.Location = new System.Drawing.Point(154, 42);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(137, 40);
            this.textBox1.TabIndex = 48;
            this.textBox1.Text = "b區域";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.Aqua;
            this.label40.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label40.Location = new System.Drawing.Point(12, 191);
            this.label40.Name = "label40";
            this.label40.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label40.Size = new System.Drawing.Size(136, 40);
            this.label40.TabIndex = 47;
            this.label40.Text = "狀態顯示";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.Aqua;
            this.label41.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label41.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label41.Location = new System.Drawing.Point(12, 142);
            this.label41.Name = "label41";
            this.label41.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label41.Size = new System.Drawing.Size(136, 40);
            this.label41.TabIndex = 46;
            this.label41.Text = "使用者";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.Aqua;
            this.label42.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label42.Location = new System.Drawing.Point(12, 92);
            this.label42.Name = "label42";
            this.label42.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label42.Size = new System.Drawing.Size(136, 40);
            this.label42.TabIndex = 45;
            this.label42.Text = "工件名稱";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.Color.Aqua;
            this.label43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label43.Location = new System.Drawing.Point(155, 191);
            this.label43.Name = "label43";
            this.label43.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label43.Size = new System.Drawing.Size(136, 40);
            this.label43.TabIndex = 44;
            this.label43.Text = "關機狀態";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.Aqua;
            this.label47.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label47.Location = new System.Drawing.Point(12, 42);
            this.label47.Name = "label47";
            this.label47.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label47.Size = new System.Drawing.Size(136, 40);
            this.label47.TabIndex = 40;
            this.label47.Text = "區域顯示";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.DodgerBlue;
            this.groupBox8.Controls.Add(this.textBox11);
            this.groupBox8.Controls.Add(this.button10);
            this.groupBox8.Controls.Add(this.pictureBox3);
            this.groupBox8.Controls.Add(this.label49);
            this.groupBox8.Controls.Add(this.groupBox9);
            this.groupBox8.Location = new System.Drawing.Point(636, 106);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox8.Size = new System.Drawing.Size(325, 587);
            this.groupBox8.TabIndex = 40;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "CNC銑床";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(159, 43);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(123, 40);
            this.textBox11.TabIndex = 41;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.DarkGray;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button10.Location = new System.Drawing.Point(147, 256);
            this.button10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(139, 40);
            this.button10.TabIndex = 38;
            this.button10.Text = "紀錄資料";
            this.button10.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.Color.LightGray;
            this.label49.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label49.Location = new System.Drawing.Point(19, 46);
            this.label49.Name = "label49";
            this.label49.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label49.Size = new System.Drawing.Size(136, 40);
            this.label49.TabIndex = 1;
            this.label49.Text = "工單件數";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.groupBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox9.Controls.Add(this.textBox6);
            this.groupBox9.Controls.Add(this.textBox5);
            this.groupBox9.Controls.Add(this.textBox4);
            this.groupBox9.Controls.Add(this.label50);
            this.groupBox9.Controls.Add(this.label51);
            this.groupBox9.Controls.Add(this.label52);
            this.groupBox9.Controls.Add(this.lab_m3_status);
            this.groupBox9.Controls.Add(this.label57);
            this.groupBox9.Location = new System.Drawing.Point(5, 322);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox9.Size = new System.Drawing.Size(300, 240);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "機台履歷";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.Cyan;
            this.textBox6.Location = new System.Drawing.Point(155, 146);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(137, 40);
            this.textBox6.TabIndex = 51;
            this.textBox6.Text = "邱建榕";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.Cyan;
            this.textBox5.Location = new System.Drawing.Point(154, 96);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(137, 40);
            this.textBox5.TabIndex = 50;
            this.textBox5.Text = "33工件";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.Cyan;
            this.textBox4.Location = new System.Drawing.Point(155, 42);
            this.textBox4.Name = "textBox4";
            this.textBox4.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.textBox4.Size = new System.Drawing.Size(137, 40);
            this.textBox4.TabIndex = 49;
            this.textBox4.Text = "c區域";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label50
            // 
            this.label50.BackColor = System.Drawing.Color.Aqua;
            this.label50.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label50.Location = new System.Drawing.Point(12, 191);
            this.label50.Name = "label50";
            this.label50.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label50.Size = new System.Drawing.Size(136, 40);
            this.label50.TabIndex = 47;
            this.label50.Text = "狀態顯示";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label51
            // 
            this.label51.BackColor = System.Drawing.Color.Aqua;
            this.label51.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label51.Location = new System.Drawing.Point(12, 142);
            this.label51.Name = "label51";
            this.label51.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label51.Size = new System.Drawing.Size(136, 40);
            this.label51.TabIndex = 46;
            this.label51.Text = "使用者";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label52
            // 
            this.label52.BackColor = System.Drawing.Color.Aqua;
            this.label52.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label52.Location = new System.Drawing.Point(12, 92);
            this.label52.Name = "label52";
            this.label52.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label52.Size = new System.Drawing.Size(136, 40);
            this.label52.TabIndex = 45;
            this.label52.Text = "工件名稱";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_m3_status
            // 
            this.lab_m3_status.BackColor = System.Drawing.Color.Aqua;
            this.lab_m3_status.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_m3_status.Location = new System.Drawing.Point(155, 191);
            this.lab_m3_status.Name = "lab_m3_status";
            this.lab_m3_status.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_m3_status.Size = new System.Drawing.Size(136, 40);
            this.lab_m3_status.TabIndex = 44;
            this.lab_m3_status.Text = "關機狀態";
            this.lab_m3_status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.BackColor = System.Drawing.Color.Aqua;
            this.label57.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label57.Location = new System.Drawing.Point(12, 42);
            this.label57.Name = "label57";
            this.label57.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label57.Size = new System.Drawing.Size(136, 40);
            this.label57.TabIndex = 40;
            this.label57.Text = "區域顯示";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.Color.Red;
            this.label62.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label62.Location = new System.Drawing.Point(660, 701);
            this.label62.Name = "label62";
            this.label62.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label62.Size = new System.Drawing.Size(157, 40);
            this.label62.TabIndex = 51;
            this.label62.Text = "紅色:危險";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Yellow;
            this.groupBox4.Controls.Add(this.textBox10);
            this.groupBox4.Controls.Add(this.button7);
            this.groupBox4.Controls.Add(this.pictureBox1);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Location = new System.Drawing.Point(21, 96);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Size = new System.Drawing.Size(609, 313);
            this.groupBox4.TabIndex = 37;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "擠出機生產線";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(162, 46);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(123, 40);
            this.textBox10.TabIndex = 40;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DarkGray;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button7.Location = new System.Drawing.Point(146, 253);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(139, 40);
            this.button7.TabIndex = 38;
            this.button7.Text = "紀錄資料";
            this.button7.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.groupBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox5.Controls.Add(this.textBox9);
            this.groupBox5.Controls.Add(this.textBox8);
            this.groupBox5.Controls.Add(this.lab_Machine_status);
            this.groupBox5.Controls.Add(this.textBox7);
            this.groupBox5.Controls.Add(this.lab_sa1);
            this.groupBox5.Controls.Add(this.lab_sc1_pno);
            this.groupBox5.Controls.Add(this.lab_sc1_sno);
            this.groupBox5.Controls.Add(this.lab_sc1_pok);
            this.groupBox5.Controls.Add(this.lab_motor);
            this.groupBox5.Controls.Add(this.lab_sc1_sok);
            this.groupBox5.Controls.Add(this.lab_sp1);
            this.groupBox5.Controls.Add(this.lab_st1);
            this.groupBox5.Controls.Add(this.lab_ss1);
            this.groupBox5.Controls.Add(this.lab_down);
            this.groupBox5.Controls.Add(this.lab_down_c);
            this.groupBox5.Controls.Add(this.lab_trun_c);
            this.groupBox5.Controls.Add(this.lab_up_c);
            this.groupBox5.Controls.Add(this.lab_up);
            this.groupBox5.Controls.Add(this.lab_trun);
            this.groupBox5.Controls.Add(this.label37);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.label30);
            this.groupBox5.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox5.Location = new System.Drawing.Point(301, 37);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Size = new System.Drawing.Size(302, 252);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "機台履歷";
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.Cyan;
            this.textBox9.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.textBox9.Location = new System.Drawing.Point(155, 142);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(136, 40);
            this.textBox9.TabIndex = 67;
            this.textBox9.Text = "鄭錦明";
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.Cyan;
            this.textBox8.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.textBox8.Location = new System.Drawing.Point(154, 93);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(136, 40);
            this.textBox8.TabIndex = 66;
            this.textBox8.Text = "3號工件";
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lab_Machine_status
            // 
            this.lab_Machine_status.BackColor = System.Drawing.Color.Aqua;
            this.lab_Machine_status.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_Machine_status.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_Machine_status.Location = new System.Drawing.Point(155, 191);
            this.lab_Machine_status.Name = "lab_Machine_status";
            this.lab_Machine_status.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_Machine_status.Size = new System.Drawing.Size(136, 40);
            this.lab_Machine_status.TabIndex = 65;
            this.lab_Machine_status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.Cyan;
            this.textBox7.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.textBox7.Location = new System.Drawing.Point(155, 42);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(136, 40);
            this.textBox7.TabIndex = 64;
            this.textBox7.Text = "A區域";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lab_sa1
            // 
            this.lab_sa1.BackColor = System.Drawing.Color.Aqua;
            this.lab_sa1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_sa1.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_sa1.Location = new System.Drawing.Point(314, 191);
            this.lab_sa1.Name = "lab_sa1";
            this.lab_sa1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_sa1.Size = new System.Drawing.Size(136, 40);
            this.lab_sa1.TabIndex = 63;
            this.lab_sa1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_sc1_pno
            // 
            this.lab_sc1_pno.BackColor = System.Drawing.Color.Aqua;
            this.lab_sc1_pno.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_sc1_pno.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_sc1_pno.Location = new System.Drawing.Point(456, 191);
            this.lab_sc1_pno.Name = "lab_sc1_pno";
            this.lab_sc1_pno.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_sc1_pno.Size = new System.Drawing.Size(136, 40);
            this.lab_sc1_pno.TabIndex = 62;
            this.lab_sc1_pno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_sc1_sno
            // 
            this.lab_sc1_sno.BackColor = System.Drawing.Color.Aqua;
            this.lab_sc1_sno.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_sc1_sno.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_sc1_sno.Location = new System.Drawing.Point(456, 143);
            this.lab_sc1_sno.Name = "lab_sc1_sno";
            this.lab_sc1_sno.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_sc1_sno.Size = new System.Drawing.Size(136, 40);
            this.lab_sc1_sno.TabIndex = 61;
            this.lab_sc1_sno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_sc1_pok
            // 
            this.lab_sc1_pok.BackColor = System.Drawing.Color.Aqua;
            this.lab_sc1_pok.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_sc1_pok.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_sc1_pok.Location = new System.Drawing.Point(456, 92);
            this.lab_sc1_pok.Name = "lab_sc1_pok";
            this.lab_sc1_pok.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_sc1_pok.Size = new System.Drawing.Size(136, 40);
            this.lab_sc1_pok.TabIndex = 60;
            this.lab_sc1_pok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_motor
            // 
            this.lab_motor.BackColor = System.Drawing.Color.Aqua;
            this.lab_motor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_motor.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_motor.Location = new System.Drawing.Point(456, 256);
            this.lab_motor.Name = "lab_motor";
            this.lab_motor.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_motor.Size = new System.Drawing.Size(136, 40);
            this.lab_motor.TabIndex = 58;
            this.lab_motor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_sc1_sok
            // 
            this.lab_sc1_sok.BackColor = System.Drawing.Color.Aqua;
            this.lab_sc1_sok.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_sc1_sok.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_sc1_sok.Location = new System.Drawing.Point(456, 42);
            this.lab_sc1_sok.Name = "lab_sc1_sok";
            this.lab_sc1_sok.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_sc1_sok.Size = new System.Drawing.Size(136, 40);
            this.lab_sc1_sok.TabIndex = 57;
            this.lab_sc1_sok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_sp1
            // 
            this.lab_sp1.BackColor = System.Drawing.Color.Aqua;
            this.lab_sp1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_sp1.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_sp1.Location = new System.Drawing.Point(314, 143);
            this.lab_sp1.Name = "lab_sp1";
            this.lab_sp1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_sp1.Size = new System.Drawing.Size(136, 40);
            this.lab_sp1.TabIndex = 56;
            this.lab_sp1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_st1
            // 
            this.lab_st1.BackColor = System.Drawing.Color.Aqua;
            this.lab_st1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_st1.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_st1.Location = new System.Drawing.Point(314, 43);
            this.lab_st1.Name = "lab_st1";
            this.lab_st1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_st1.Size = new System.Drawing.Size(136, 40);
            this.lab_st1.TabIndex = 55;
            this.lab_st1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_ss1
            // 
            this.lab_ss1.BackColor = System.Drawing.Color.Aqua;
            this.lab_ss1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_ss1.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_ss1.Location = new System.Drawing.Point(314, 93);
            this.lab_ss1.Name = "lab_ss1";
            this.lab_ss1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_ss1.Size = new System.Drawing.Size(136, 40);
            this.lab_ss1.TabIndex = 54;
            this.lab_ss1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_down
            // 
            this.lab_down.BackColor = System.Drawing.Color.Aqua;
            this.lab_down.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_down.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_down.Location = new System.Drawing.Point(314, 256);
            this.lab_down.Name = "lab_down";
            this.lab_down.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_down.Size = new System.Drawing.Size(136, 40);
            this.lab_down.TabIndex = 53;
            this.lab_down.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_down_c
            // 
            this.lab_down_c.BackColor = System.Drawing.Color.Aqua;
            this.lab_down_c.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_down_c.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_down_c.Location = new System.Drawing.Point(314, 307);
            this.lab_down_c.Name = "lab_down_c";
            this.lab_down_c.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_down_c.Size = new System.Drawing.Size(136, 40);
            this.lab_down_c.TabIndex = 52;
            this.lab_down_c.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_trun_c
            // 
            this.lab_trun_c.BackColor = System.Drawing.Color.Aqua;
            this.lab_trun_c.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_trun_c.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_trun_c.Location = new System.Drawing.Point(30, 307);
            this.lab_trun_c.Name = "lab_trun_c";
            this.lab_trun_c.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_trun_c.Size = new System.Drawing.Size(136, 40);
            this.lab_trun_c.TabIndex = 51;
            this.lab_trun_c.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_up_c
            // 
            this.lab_up_c.BackColor = System.Drawing.Color.Aqua;
            this.lab_up_c.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_up_c.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_up_c.Location = new System.Drawing.Point(172, 307);
            this.lab_up_c.Name = "lab_up_c";
            this.lab_up_c.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_up_c.Size = new System.Drawing.Size(136, 40);
            this.lab_up_c.TabIndex = 50;
            this.lab_up_c.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_up
            // 
            this.lab_up.BackColor = System.Drawing.Color.Aqua;
            this.lab_up.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_up.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_up.Location = new System.Drawing.Point(172, 256);
            this.lab_up.Name = "lab_up";
            this.lab_up.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_up.Size = new System.Drawing.Size(136, 40);
            this.lab_up.TabIndex = 49;
            this.lab_up.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_trun
            // 
            this.lab_trun.BackColor = System.Drawing.Color.Aqua;
            this.lab_trun.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lab_trun.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.lab_trun.Location = new System.Drawing.Point(30, 256);
            this.lab_trun.Name = "lab_trun";
            this.lab_trun.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lab_trun.Size = new System.Drawing.Size(136, 40);
            this.lab_trun.TabIndex = 48;
            this.lab_trun.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.Aqua;
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label37.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label37.Location = new System.Drawing.Point(12, 191);
            this.label37.Name = "label37";
            this.label37.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label37.Size = new System.Drawing.Size(136, 40);
            this.label37.TabIndex = 47;
            this.label37.Text = "狀態顯示";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.Aqua;
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label36.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.label36.Location = new System.Drawing.Point(12, 142);
            this.label36.Name = "label36";
            this.label36.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label36.Size = new System.Drawing.Size(136, 40);
            this.label36.TabIndex = 46;
            this.label36.Text = "使用者";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.Aqua;
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label35.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.label35.Location = new System.Drawing.Point(12, 92);
            this.label35.Name = "label35";
            this.label35.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label35.Size = new System.Drawing.Size(136, 40);
            this.label35.TabIndex = 45;
            this.label35.Text = "工件名稱";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.Aqua;
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label30.Font = new System.Drawing.Font("標楷體", 16.2F);
            this.label30.Location = new System.Drawing.Point(12, 42);
            this.label30.Name = "label30";
            this.label30.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label30.Size = new System.Drawing.Size(136, 40);
            this.label30.TabIndex = 40;
            this.label30.Text = "區域顯示";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.LightGray;
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label21.Location = new System.Drawing.Point(19, 46);
            this.label21.Name = "label21";
            this.label21.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label21.Size = new System.Drawing.Size(136, 40);
            this.label21.TabIndex = 1;
            this.label21.Text = "工單件數";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.Color.Lime;
            this.label60.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label60.Location = new System.Drawing.Point(496, 701);
            this.label60.Name = "label60";
            this.label60.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label60.Size = new System.Drawing.Size(157, 40);
            this.label60.TabIndex = 49;
            this.label60.Text = "綠色:待機";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label28.Location = new System.Drawing.Point(173, 42);
            this.label28.Name = "label28";
            this.label28.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label28.Size = new System.Drawing.Size(136, 40);
            this.label28.TabIndex = 2;
            this.label28.Text = "工單總數";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.Color.Yellow;
            this.label59.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label59.Location = new System.Drawing.Point(332, 701);
            this.label59.Name = "label59";
            this.label59.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label59.Size = new System.Drawing.Size(157, 40);
            this.label59.TabIndex = 48;
            this.label59.Text = "黃色:運轉";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label59.Click += new System.EventHandler(this.label59_Click);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Location = new System.Drawing.Point(315, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 40);
            this.label6.TabIndex = 36;
            this.label6.Text = "       ";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button8.Location = new System.Drawing.Point(445, 42);
            this.button8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(93, 40);
            this.button8.TabIndex = 35;
            this.button8.Text = "分配";
            this.button8.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button8.UseVisualStyleBackColor = false;
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.Font = new System.Drawing.Font("標楷體", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "PP/PS板",
            "傘形齒輪",
            "螺絲"});
            this.comboBox2.Location = new System.Drawing.Point(21, 45);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(143, 35);
            this.comboBox2.TabIndex = 33;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // timer1
            // 
            this.timer1.Interval = 300;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 200;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // serialPort1
            // 
            this.serialPort1.PortName = "COM7";
            // 
            // timer3
            // 
            this.timer3.Interval = 10;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PLC自動化機台遠端監控.Properties.Resources.機台二V;
            this.pictureBox2.Location = new System.Drawing.Point(19, 89);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(267, 145);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 39;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::PLC自動化機台遠端監控.Properties.Resources.機台三;
            this.pictureBox3.Location = new System.Drawing.Point(19, 100);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(267, 150);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 39;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PLC自動化機台遠端監控.Properties.Resources.機台一;
            this.pictureBox1.Location = new System.Drawing.Point(19, 89);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(267, 160);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 39;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label27);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lab_el;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lab_ev;
        private System.Windows.Forms.Label lab_ef;
        private System.Windows.Forms.Label lab_ec;
        private System.Windows.Forms.Label lab_eh;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lab_et;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label lab_m3_status;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label lab_time;
        private System.Windows.Forms.Label lab_data;
        private System.Windows.Forms.Label lab_down;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label lab_trun;
        private System.Windows.Forms.Label lab_up;
        private System.Windows.Forms.Label lab_up_c;
        private System.Windows.Forms.Label lab_trun_c;
        private System.Windows.Forms.Label lab_down_c;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lab_sc1_sok;
        private System.Windows.Forms.Label lab_sp1;
        private System.Windows.Forms.Label lab_ss1;
        private System.Windows.Forms.Label lab_sc1_pno;
        private System.Windows.Forms.Label lab_sc1_sno;
        private System.Windows.Forms.Label lab_sc1_pok;
        private System.Windows.Forms.Label lab_motor;
        private System.Windows.Forms.Label lab_sc2_sno;
        private System.Windows.Forms.Label lab_sp2;
        private System.Windows.Forms.Label lab_ss2;
        private System.Windows.Forms.Label lab_sc2_pno;
        private System.Windows.Forms.Label lab_sc2_pok;
        private System.Windows.Forms.Label lab_sc2_sok;
        private System.Windows.Forms.Label lab_st2;
        private System.Windows.Forms.Label lab_sa2;
        private System.Windows.Forms.Label lab_sa1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label lab_Machine_status;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label lab_st1;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label4;
    }
}

