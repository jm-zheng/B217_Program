﻿Imports MySql.Data.MySqlClient
Module MySQL

    Public Sub MySQL_Init(ByRef SQL As SQL_TypeDef, ByVal iArrayMax As Integer, ByRef iServerID As String,
                          ByRef iUserID As String, ByRef iPassword As String, ByRef iDatabase As String)
        ReDim SQL.Column(iArrayMax)
        serverstring = "server=" & iServerID & ";userid= " & iUserID & ";password=" & iPassword & ";Database=" & iDatabase & ";charset=utf8;Allow Zero Datetime=True;"
        SQL.SQLConnection = New MySqlConnection
        SQL.SQLConnection.ConnectionString = serverstring
    End Sub

    Public Sub MySQL_Add(ByVal SQL As SQL_TypeDef, ByVal Number As Integer)

        Dim SQLStatement As String = Nothing
        SQLStatement = "INSERT INTO `" & SQL.Form & "` ("
        SQLStatement &= "`date`,`time`,"

        For index = 1 To Number
            SQLStatement &= "`" & index & "`"

            If index = Number Then
                SQLStatement &= ")"
            Else
                SQLStatement &= ","
            End If
        Next

        SQLStatement &= "VALUES("
        SQLStatement &= "'" & Format(DateValue(SQL.Date_YMD), "yyyy-MM-dd") & "','" & Format(TimeValue(SQL.Time), "HH:mm:ss") & "',"

        For index = 1 To Number
            SQLStatement &= "'" & SQL.Column(index) & "'"
            If index = Number Then
                SQLStatement &= ")"
            Else
                SQLStatement &= ","
            End If
        Next
        Try
            MySQL_Disconnection(SQL)
            MySQL_Connection(SQL)
            MySQL_Savedata(SQLStatement, SQL)
            MySQL_Disconnection(SQL)
        Catch ex As Exception
            If Debug = iOPEN Then
                '錯誤行數
                Dim trace = New System.Diagnostics.StackTrace(ex, True)
                Dim line As String = trace.GetFrame(trace.FrameCount - 1).GetFileLineNumber()
                Dim filename = My.Computer.FileSystem.GetName(trace.GetFrame(trace.FrameCount - 1).GetFileName)
                Dim functionname = trace.GetFrame(trace.FrameCount - 1).GetMethod.Name
                Console.WriteLine("")
                Console.WriteLine("error  " & filename & " > " & functionname & "   Line:" & line)
                Console.WriteLine("Error message :")
                Console.WriteLine(ex.Message)
                Console.WriteLine("")
                'Return False
            ElseIf Debug = iRETURN Then
                'Return ex.ToString
            Else
                'Return False
            End If
        End Try
    End Sub


    'RETERIEVE DATA 
    Public Function MySQL_Retrieve(ByVal SQL As SQL_TypeDef)
        Dim mysql_adapter As MySqlDataAdapter
        Dim cmd As MySqlCommand
        Dim dt As New DataTable()
        'SQL STMT
        Dim sqlstring As String = "SELECT * FROM " & SQL.Form ' SHOW FULL FIELDS FROM 資料庫.資料表   看註解用

        cmd = New MySqlCommand(sqlstring, SQL.SQLConnection)



        'OPEN CON,RETRIEVE,FILL DGVIEW
        Try
            MySQL_Disconnection(SQL)
            MySQL_Connection(SQL)
            mysql_adapter = New MySqlDataAdapter(cmd)

            mysql_adapter.Fill(dt)

            MySQL_Disconnection(SQL)

            'CLEAR DT
            Return dt

        Catch ex As Exception
            If Debug = iOPEN Then
                '錯誤行數
                Dim trace = New System.Diagnostics.StackTrace(ex, True)
                Dim line As String = trace.GetFrame(trace.FrameCount - 1).GetFileLineNumber()
                Dim filename = My.Computer.FileSystem.GetName(trace.GetFrame(trace.FrameCount - 1).GetFileName)
                Dim functionname = trace.GetFrame(trace.FrameCount - 1).GetMethod.Name
                Console.WriteLine("")
                Console.WriteLine("error  " & filename & " > " & functionname & "   Line:" & line)
                Console.WriteLine("Error message :")
                Console.WriteLine(ex.Message)
                Console.WriteLine("")
                'Return False
            ElseIf Debug = iRETURN Then
                'Return ex.ToString
            Else
                'Return False
            End If
            Return dt
            'SQLConnection.Close()
        End Try

    End Function

    Public Sub MySQL_Update(ByVal SQL As SQL_TypeDef, ByVal dt As DataTable, ByVal id As String)

        ' Dim con As New MySqlConnection(serverstring)
        Dim adapter As MySqlDataAdapter
        Dim cmd As MySqlCommand
        Dim SQLStatement As String = Nothing
        SQLStatement = "UPDATE " & SQL.Form & " SET "

        For index = 1 To dt.Columns.Count - 3
            'SQLStatement &= "`" & index & "`" & "=" & "'" & dt.Rows(0).Item(index) & "'"
            SQLStatement &= "`" & index & "`" & "=" & "'" & dt.Rows(id).Item(index.ToString) & "'"
            If index = dt.Columns.Count - 3 Then
                SQLStatement &= " WHERE id=" & dt.Rows(id).Item(0)
            Else
                SQLStatement &= ","
            End If
        Next
        cmd = New MySqlCommand(SQLStatement, SQL.SQLConnection)

        'OPEN CON,EXECUT UPDATE,CLOSE'
        Try
            MySQL_Disconnection(SQL)
            MySQL_Connection(SQL)

            adapter = New MySqlDataAdapter(cmd)
            adapter.UpdateCommand = SQL.SQLConnection.CreateCommand()

            adapter.UpdateCommand.CommandText = SQLStatement

            If adapter.UpdateCommand.ExecuteNonQuery() > 0 Then
                'MsgBox("Successfully Updated")
            End If
            'con.Close()
            MySQL_Disconnection(SQL)
        Catch ex As Exception
            If Debug = iOPEN Then
                '錯誤行數
                Dim trace = New System.Diagnostics.StackTrace(ex, True)
                Dim line As String = trace.GetFrame(trace.FrameCount - 1).GetFileLineNumber()
                Dim filename = My.Computer.FileSystem.GetName(trace.GetFrame(trace.FrameCount - 1).GetFileName)
                Dim functionname = trace.GetFrame(trace.FrameCount - 1).GetMethod.Name
                Console.WriteLine("")
                Console.WriteLine("error  " & filename & " > " & functionname & "   Line:" & line)
                Console.WriteLine("Error message :")
                Console.WriteLine(ex.Message)
                Console.WriteLine("")
                'Return False
            ElseIf Debug = iRETURN Then
                'Return ex.ToString
            Else
                'Return False
            End If
        End Try
    End Sub

    Public Sub MySQL_Delete(ByVal SQL As SQL_TypeDef, id As String)
        'Dim con As New MySqlConnection(serverstring)
        Dim mysql_adapter As MySqlDataAdapter
        Dim sqlstring As String = "DELETE FROM " & SQL.Form & " WHERE ID='" & id & "'"
        Dim cmd As MySqlCommand
        cmd = New MySqlCommand(sqlstring, SQL.SQLConnection)



        'OPEN CON,EXECUTE UPDATE,CLOSE CON
        Try
            MySQL_Disconnection(SQL)
            MySQL_Connection(SQL)
            mysql_adapter = New MySqlDataAdapter(cmd)
            mysql_adapter.DeleteCommand = SQL.SQLConnection.CreateCommand()
            mysql_adapter.DeleteCommand.CommandText = sqlstring

            'PROMPT FOR CONFIRMATION
            'If MessageBox.Show("Sure ??", "DELETE", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) = System.Windows.Forms.DialogResult.OK Then
            If cmd.ExecuteNonQuery() > 0 Then
                'MsgBox("Successfully Deleted")
            End If
            ' End If
            MySQL_Disconnection(SQL)
        Catch ex As Exception
            If Debug = iOPEN Then
                '錯誤行數
                Dim trace = New System.Diagnostics.StackTrace(ex, True)
                Dim line As String = trace.GetFrame(trace.FrameCount - 1).GetFileLineNumber()
                Dim filename = My.Computer.FileSystem.GetName(trace.GetFrame(trace.FrameCount - 1).GetFileName)
                Dim functionname = trace.GetFrame(trace.FrameCount - 1).GetMethod.Name
                Console.WriteLine("")
                Console.WriteLine("error  " & filename & " > " & functionname & "   Line:" & line)
                Console.WriteLine("Error message :")
                Console.WriteLine(ex.Message)
                Console.WriteLine("")
                'Return False
            ElseIf Debug = iRETURN Then
                'Return ex.ToString
            Else
                'Return False
            End If
        End Try

    End Sub

    'Select DATA 
    Public Function MySQL_Select(ByVal SQL As SQL_TypeDef, ByVal col As String, ByVal val As String)
        Dim mysql_adapter As MySqlDataAdapter
        Dim cmd As MySqlCommand
        Dim dt As New DataTable()
        'SQL STMT
        Dim sqlstring As String = ""
        If val <> "" Then
            sqlstring = "SELECT * FROM " & SQL.Form & " WHERE `" & col & "`='" & val & "'"
        Else
            sqlstring = "SELECT * FROM " & SQL.Form & " WHERE `" & col & "`"
        End If


        cmd = New MySqlCommand(sqlstring, SQL.SQLConnection)

        MySQL_Connection(SQL)

        'OPEN CON,RETRIEVE,FILL DGVIEW
        Try

            mysql_adapter = New MySqlDataAdapter(cmd)

            mysql_adapter.Fill(dt)

            'CLEAR DT
            Return dt

        Catch ex As Exception
            If Debug = iOPEN Then
                '錯誤行數
                Dim trace = New System.Diagnostics.StackTrace(ex, True)
                Dim line As String = trace.GetFrame(trace.FrameCount - 1).GetFileLineNumber()
                Dim filename = My.Computer.FileSystem.GetName(trace.GetFrame(trace.FrameCount - 1).GetFileName)
                Dim functionname = trace.GetFrame(trace.FrameCount - 1).GetMethod.Name
                Console.WriteLine("")
                Console.WriteLine("error  " & filename & " > " & functionname & "   Line:" & line)
                Console.WriteLine("Error message :")
                Console.WriteLine(ex.Message)
                Console.WriteLine("")
                'Return False
            ElseIf Debug = iRETURN Then
                'Return ex.ToString
            Else
                'Return False
            End If
            Return dt
            'SQLConnection.Close()
        End Try

        MySQL_Disconnection(SQL)

    End Function

    'Public Sub DataGridView_SET(ByVal dgv As DataGridView, ByVal dt As DataTable)

    '    dgv.DataSource = dt

    'End Sub

    Public Sub MySQL_Show_Label(ByVal SQL As SQL_TypeDef, Optional ByVal data_space_count As Integer = 13)
        Try
            Dim table As New DataTable
            table = MYSQL_Label_Type(SQL)

            Dim data_space_str As String = "                    "
            Dim data_dash_str As String = "--------------------"
            Dim count As Integer = 0
            For Each col As DataRow In table.Rows
                count += 1
                'If count = 1 Then
                '    Console.Write("{0,-" & data_space & "}", col.Item(0))
                'Else
                '    Console.Write("{0,-" & (data_space - 1) - ((col.Item(0).length - 1) * 2) + col.Item(0).length - 1 & "}", col.Item(0)) ' "{0,-" & 16 - (col.Item(0).length * 2 - 1) & "}"
                'End If


                Console.Write(col.Item(0))
                Console.Write(Mid(data_space_str, 1, data_space_count - System.Text.Encoding.Default.GetBytes(col.Item(0)).Length()))


            Next
            Console.WriteLine()

            table = MySQL_Retrieve(SQL)
            For Each col As DataColumn In table.Columns
                Console.Write("{0,-" & data_space_count & "}", col.ColumnName)
            Next
            Console.WriteLine()

            For index = 1 To count
                Console.Write(Mid(data_dash_str, 1, data_space_count))
            Next
            Console.WriteLine()

            For Each row As DataRow In table.Rows
                For Each col As DataColumn In table.Columns
                    'If col.DataType.Equals(GetType(DateTime)) Then
                    '    Console.Write("{0,-" & data_space_count & ":d}", row(col))
                    'ElseIf col.DataType.Equals(GetType([Decimal])) Then
                    '    Console.Write("{0,-" & data_space_count & ":C}", row(col))
                    'Else
                    '    Console.Write("{0,-" & data_space_count & "}", row(col))
                    'End If
                    Console.Write(row(col))
                    Console.Write(Mid(data_space_str, 1, data_space_count - System.Text.Encoding.Default.GetBytes(row(col).ToString).Length()))
                Next
                Console.WriteLine()
            Next
            Console.WriteLine()
        Catch ex As Exception

        End Try

    End Sub

    Public Function MYSQL_Label_Type(ByVal SQL As SQL_TypeDef)
        Dim mysql_adapter As MySqlDataAdapter
        Dim cmd As MySqlCommand
        Dim dt As New DataTable()

        Dim sqlstring As String = "Select COLUMN_COMMENT FROM information_schema.columns WHERE table_name ='" & SQL.Form & "'"

        cmd = New MySqlCommand(sqlstring, SQL.SQLConnection)

        MySQL_Connection(SQL)

        'OPEN CON,RETRIEVE,FILL DGVIEW
        Try

            mysql_adapter = New MySqlDataAdapter(cmd)

            mysql_adapter.Fill(dt)

            'CLEAR DT
            Return dt

        Catch ex As Exception
            If Debug = iOPEN Then
                '錯誤行數
                Dim trace = New System.Diagnostics.StackTrace(ex, True)
                Dim line As String = trace.GetFrame(trace.FrameCount - 1).GetFileLineNumber()
                Dim filename = My.Computer.FileSystem.GetName(trace.GetFrame(trace.FrameCount - 1).GetFileName)
                Dim functionname = trace.GetFrame(trace.FrameCount - 1).GetMethod.Name
                Console.WriteLine("")
                Console.WriteLine("error  " & filename & " > " & functionname & "   Line:" & line)
                Console.WriteLine("Error message :")
                Console.WriteLine(ex.Message)
                Console.WriteLine("")
                'Return False
            ElseIf Debug = iRETURN Then
                'Return ex.ToString
            Else
                'Return False
            End If
            Return dt
            'SQLConnection.Close()
        End Try

        MySQL_Disconnection(SQL)
    End Function

    '====================================   OH!!  NO!!   ====================================
    '=============================   Back to the top ,please   ==============================

    Const Debug As Integer = iOPEN

    Structure SQL_TypeDef
        Dim SQLConnection As MySqlConnection
        Dim Form As String
        Dim Date_YMD As String
        Dim Time As String
        Dim Column() As String

    End Structure

    Const iOPEN As Integer = 1
    Const iCLOSE As Integer = 2
    Const iRETURN As Integer = 3

    Dim serverstring As String = "server=127.0.0.1;userid=root;password=;Database=shong;charset=utf8;Allow Zero Datetime=True;" 'My Database


    Public Function MySQL_Connection(ByVal SQL As SQL_TypeDef)

        Try
            If SQL.SQLConnection.State = ConnectionState.Open Then
                SQL.SQLConnection.Close()
            End If
            If SQL.SQLConnection.State = ConnectionState.Closed Then
                SQL.SQLConnection.Open()
                'MsgBox("Successfully Connected to MySQL Database.")
            End If
            Return True
        Catch ex As Exception
            If Debug = iOPEN Then
                '錯誤行數
                Dim trace = New System.Diagnostics.StackTrace(ex, True)
                Dim line As String = trace.GetFrame(trace.FrameCount - 1).GetFileLineNumber()
                Dim filename = My.Computer.FileSystem.GetName(trace.GetFrame(trace.FrameCount - 1).GetFileName)
                Dim functionname = trace.GetFrame(trace.FrameCount - 1).GetMethod.Name
                Console.WriteLine("")
                Console.WriteLine("error  " & filename & " > " & functionname & "   Line:" & line)
                Console.WriteLine("Error message :")
                Console.WriteLine(ex.Message)
                Console.WriteLine("")
                Return False
            ElseIf Debug = iRETURN Then
                Return ex.ToString
            Else
                Return False
            End If
        End Try
    End Function

    Public Function MySQL_Disconnection(ByVal SQL As SQL_TypeDef)

        Try
            If SQL.SQLConnection.State = ConnectionState.Open Then
                SQL.SQLConnection.Close()
            End If
            Return True
        Catch ex As Exception
            If Debug = iOPEN Then
                '錯誤行數
                Dim trace = New System.Diagnostics.StackTrace(ex, True)
                Dim line As String = trace.GetFrame(trace.FrameCount - 1).GetFileLineNumber()
                Dim filename = My.Computer.FileSystem.GetName(trace.GetFrame(trace.FrameCount - 1).GetFileName)
                Dim functionname = trace.GetFrame(trace.FrameCount - 1).GetMethod.Name
                Console.WriteLine("")
                Console.WriteLine("error  " & filename & " > " & functionname & "   Line:" & line)
                Console.WriteLine("Error message :")
                Console.WriteLine(ex.Message)
                Console.WriteLine("")

                'MsgBox(ex.ToString)
                Return False
            ElseIf Debug = iRETURN Then
                Return ex.ToString
            Else
                Return False
            End If
        End Try
    End Function

    Public Sub MySQL_Savedata(ByRef aa As String, ByVal SQL As SQL_TypeDef)
        Dim cmd As MySqlCommand = New MySqlCommand
        With cmd
            .CommandText = aa
            .CommandType = CommandType.Text
            .Connection = SQL.SQLConnection
            .ExecuteNonQuery()
        End With
    End Sub

    'DataGridView INIT
    'Public Sub DataGridView_INIT(ByVal dgv As DataGridView, ByVal dt As DataTable)
    '    dgv.ColumnCount = dt.Columns.Count

    '    For index = 1 To dgv.ColumnCount
    '        dgv.Columns(index - 1).Name = index
    '    Next

    'End Sub

End Module
